package com.hwadee.xnfz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Xnfz02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
