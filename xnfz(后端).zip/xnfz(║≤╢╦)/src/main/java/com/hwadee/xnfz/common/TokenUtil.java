package com.hwadee.xnfz.common;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.util.Date;

public class TokenUtil {
    //秘钥
    public static final String DEFAULT_SALT = "mydb";
    private static final String DEFAULT_CLAIM = "userId";
    private static final String DEFAULT_ISSUER = "auth0";

    private static final long EXPIRE_TIME = 30 * 60 * 1000;

    public static String sign(int userId) {
        try {
            Date date = new Date(System.currentTimeMillis() + EXPIRE_TIME);

            String token = JWT.create()
                    //认证参数
                    .withClaim(DEFAULT_CLAIM, userId)
                    //Issuer 参数
                    .withIssuer(DEFAULT_ISSUER)
                    //过期时间
                    .withExpiresAt(date)
                    //以指定加密算法生成 Token
                    .sign(Algorithm.HMAC256(DEFAULT_SALT));

            return token;
        }catch (Exception e){
            return null;
        }

    }

    public static boolean verify(String token) {
        try {
            JWTVerifier verifier = JWT.require(Algorithm.HMAC256(DEFAULT_SALT)).withIssuer(DEFAULT_ISSUER).build();
            DecodedJWT decodedJWT = verifier.verify(token);
            Integer userId = decodedJWT.getClaim(DEFAULT_CLAIM).asInt();

            return userId > 0;
        }catch (Exception e){
            System.out.println(e.getMessage());
            return false;
        }
    }

    public static int getClaim(String token) {
        try {
            JWTVerifier verifier = JWT.require(Algorithm.HMAC256(DEFAULT_SALT)).withIssuer(DEFAULT_ISSUER).build();
            DecodedJWT decodedJWT = verifier.verify(token);

            return decodedJWT.getClaim(DEFAULT_CLAIM).asInt();
        }catch (Exception e){
            return 0;
        }
    }


}
