package com.hwadee.xnfz.config;

import com.hwadee.xnfz.interceptor.TokenInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Autowired
    TokenInterceptor tokenInterceptor;
    @Override
    public void addInterceptors(InterceptorRegistry registry){
        //在当前系统中注册拦截器，拦截指定的请求
        registry.addInterceptor(tokenInterceptor)
                .addPathPatterns("/**")
                //不拦截的URL
                .excludePathPatterns(
                        "/swagger-ui.html",
                        "/webjars/**",
                        "/swagger-resources/**",
                        "/error/**",
                        "/user/login/**",
                        "/user/register/**",
                        "/dictionary/**",
                        "/course/**",
                        "/dictionary/**",
                        "/v2/**",
                        "/error/**",
                        "/equipment/export",
                        "/equipment/import",
                        "/user/import",
                        "/report/**","/favicon.ico/**"
                        );
    }

    @Override
    public void addCorsMappings(CorsRegistry registry){
        registry.addMapping("/**")
                .allowedMethods("*")
                .allowCredentials(true)
                .allowedOriginPatterns("*")
                .maxAge(60 * 60);
    }
}
