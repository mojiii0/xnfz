package com.hwadee.xnfz.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 
 * @TableName user_role
 */
@TableName(value ="user_role")
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class UserRole implements Serializable {
    /**
     * 
     */
    @TableId
    private Integer userId;
    private Integer roleId;


}