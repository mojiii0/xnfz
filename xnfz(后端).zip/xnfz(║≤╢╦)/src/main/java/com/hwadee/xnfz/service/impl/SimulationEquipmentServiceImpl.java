package com.hwadee.xnfz.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hwadee.xnfz.entity.SimulationEquipment;
import com.hwadee.xnfz.mapper.SimulationEquipmentMapper;
import com.hwadee.xnfz.service.SimulationEquipmentService;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class SimulationEquipmentServiceImpl extends ServiceImpl<SimulationEquipmentMapper, SimulationEquipment>
    implements SimulationEquipmentService{

    @Override
    public Page<SimulationEquipment> pageByCondition(IPage page, String name, String number) {
        return ((Page<SimulationEquipment>) page(
                page,
                new QueryWrapper<SimulationEquipment>()
                .like(StringUtils.hasLength(name),"name",name)
                .like(StringUtils.hasLength(number),"number",number)
        ));
    }

    @Override
    public List<SimulationEquipment> listByCondition(String name, String number) {
        return list(
                new QueryWrapper<SimulationEquipment>()
                        .like(StringUtils.hasLength(name),"name",name)
                        .like(StringUtils.hasLength(number),"number",number)
        );
    }
}




