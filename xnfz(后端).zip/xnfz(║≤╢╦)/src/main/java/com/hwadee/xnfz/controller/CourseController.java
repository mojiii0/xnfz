package com.hwadee.xnfz.controller;


import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import com.hwadee.xnfz.entity.Course;
import com.hwadee.xnfz.entity.R;
import com.hwadee.xnfz.service.CourseService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;


import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;



@Api(tags = "课程管理")
@RestController
@RequestMapping("/course")
public class CourseController {
    @Autowired
    CourseService courseService;
    @ApiOperation("主任添加课程信息")
    @PostMapping("/register")
    public R register(@RequestBody Course course) {
        // 对用户输入的数据进行合法性校验
        if (!StringUtils.hasLength(course.getNumber())) {
            return R.fail().message("课程编号不能为空");
        }
        if (!StringUtils.hasLength(course.getName())) {
            return R.fail().message("课程名称不能为空");
        }
        if (course.getIntro() == null) {
            return R.fail().message("课程描述不能为空");
        }


        // 判断账号是否已经存在
        Course existingUser = courseService.getUserByName(course.getNumber());
        if (existingUser != null) {
            return R.fail().message("账号已经存在");
        }

        // 将用户信息保存到数据库中
        courseService.saveUser(course);

        return R.ok().message("注册成功");
    }

    // 查询所有用户信息
    @ApiOperation("查询所有课程信息信息")
    @GetMapping("/all")
    public R getAllUsers() {
        List<Course> userList = courseService.getAllCourse();
        if (!userList.isEmpty()) {
            return R.ok().data(userList);
        } else {
            return R.fail().message("暂无课程信息");
        }
    }

    // 修改用户信息
    @ApiOperation("根据课程主键ID修改课程信息")
    @PutMapping("/update/{id}")
    public R updateUserById(@PathVariable("id") Long id, @RequestBody Course updatedUser) {
        // Validate the input parameters
        if (id == null || updatedUser == null) {
            return R.fail().message("参数不合理");
        }

        // Check if the user with the given ID exists in the database
        Course existingUser = courseService.getCourseById(id);
        if (existingUser == null) {
            return R.fail().message("课程不存在");
        }


        existingUser.setNumber(updatedUser.getNumber());
        existingUser.setName(updatedUser.getName());
        existingUser.setIntro(updatedUser.getIntro());
        existingUser.setCredit(updatedUser.getCredit());
        existingUser.setPeriod(updatedUser.getPeriod());
        existingUser.setTeachername(updatedUser.getTeachername());
        existingUser.setOutline(updatedUser.getOutline());
        existingUser.setResource(updatedUser.getResource());
        existingUser.setState(updatedUser.getState());



        // Save the updated user data to the database using the updateById method
        boolean isUpdated = courseService.updateById(existingUser);
        if (isUpdated) {
            return R.ok().message("主任信息修改成功");
        } else {
            return R.fail().message("主任信息修改失败");
        }
    }

    @ApiOperation("根据课程主键ID删除用户")
    @DeleteMapping("/delete/{id}")
    public R deleteUserById(@PathVariable("id") Long id) {
        if (id == null) {
            return R.fail().message("参数不合理");
        }

        Course user = courseService.getCourseById(id);
        if (user != null) {
            // 调用leaveService的方法来删除用户
            courseService.deleteCourseById(id);
            return R.ok().message("主任删除成功");
        } else {
            return R.fail().message("主任不存在");
        }
    }
    // 根据ID查询用户信息
    @ApiOperation("根据课程主键ID查询课程信息")
    @GetMapping("/{id}")
    public R getUserById(@PathVariable("id") Long id) {
        if (id == null) {
            return R.fail().message("参数不合理");
        }

        Course user = courseService.getCourseById(id);
        if (user != null) {
            return R.ok().data(user);
        } else {
            return R.fail().message("课程不存在");
        }
    }


    @ApiOperation("导出课程信息数据")
    @GetMapping("/export")
    public void export(HttpServletResponse response,
                       @RequestParam(required = false)String name,
                       @RequestParam(required = false)String number)
        throws IOException{
        //生成 Excel 对应的对象
        List<Course> courses = courseService.listByCondition(name,number);
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(),
                Course.class, courses);
        //response 写出 Excel 文件对应的对象
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                "attachment;filename=" +
                        URLEncoder.encode("simulation_equipment.xlsx",
                                String.valueOf(StandardCharsets.UTF_8)));
        response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
        workbook.write(response.getOutputStream());
    }


    
}