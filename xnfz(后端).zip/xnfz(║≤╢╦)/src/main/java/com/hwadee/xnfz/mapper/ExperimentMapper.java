package com.hwadee.xnfz.mapper;

import com.hwadee.xnfz.entity.Experiment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Administrator
* @description 针对表【experiment】的数据库操作Mapper
* @createDate 2023-08-17 15:37:05
* @Entity com.hwadee.xnfz.entity.Experiment
*/
public interface ExperimentMapper extends BaseMapper<Experiment> {

}




