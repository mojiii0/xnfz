package com.hwadee.xnfz.interceptor;

import com.hwadee.xnfz.common.TokenUtil;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Component
public class TokenInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
        //System.out.println("拦截到请求：" + request.getRequestURL());

        //所有 OPTIONS 请求都放过
        if(request.getMethod().equalsIgnoreCase("OPTIONS")){
            response.setStatus(HttpServletResponse.SC_OK);
            return true;
        }

        //获取 Token
        String token = request.getHeader("token");
        HttpSession session = request.getSession();
        //验证 Token
        if (token == null){
            //用户未认证，反馈错误信息
            request.getRequestDispatcher("/error/not_not_certified").forward(request,response);
            return false;
        } else if(!TokenUtil.verify(token)){
            //认证已过期
            request.getRequestDispatcher("/error/expired").forward(request,response);
            return false;
        }

        //如果用户已登出，则 userId 字段对应的对象在 Session 中是不存在的
        Object userId = session.getAttribute("userId");
        if(userId == null){
            request.getRequestDispatcher("/error/expired").forward(request,response);
            return false;
        }

//        Integer claim = TokenUtil.getClaim(token);
//        response.setHeader("token",TokenUtil.sign(claim));
        //TODO 注意在跨域的影响下，此Token请求信息不一定能拿到那怎么办？
//        response.setHeader("Access-Control-Expose-Headers","token");
        return true;
    }
}
