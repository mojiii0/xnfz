package com.hwadee.xnfz.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hwadee.xnfz.entity.SimulationEquipment;

/**
* @author Administrator
* @description 针对表【simulation_equipment】的数据库操作Mapper
* @createDate 2023-08-10 14:54:37
* @Entity com.hwadee.xnfz.entity.SimulationEquipment
*/
public interface SimulationEquipmentMapper extends BaseMapper<SimulationEquipment> {

}




