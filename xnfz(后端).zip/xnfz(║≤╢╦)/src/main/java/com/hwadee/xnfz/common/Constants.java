package com.hwadee.xnfz.common;

public class Constants {

    public static final String TYPE_DICTIONARY_GENDER = "gender";
    public static final String TYPE_DICTIONARY_TYPE = "TYPE";
    public static final int ROLE_ID_BASIC = 4;
}
