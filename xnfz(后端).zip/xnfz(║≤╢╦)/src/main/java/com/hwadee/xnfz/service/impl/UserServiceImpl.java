package com.hwadee.xnfz.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hwadee.xnfz.common.Constants;
import com.hwadee.xnfz.entity.User;
import com.hwadee.xnfz.entity.UserRole;
import com.hwadee.xnfz.mapper.UserRoleMapper;
import com.hwadee.xnfz.service.UserService;
import com.hwadee.xnfz.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
* @author Administrator
* @description 针对表【user】的数据库操作Service实现
* @createDate 2023-07-29 08:15:37
*/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
    implements UserService{

    @Autowired
    UserRoleMapper userRoleMapper;
    //保存用户数据及基本角色的方法
    @Override
    public boolean saveUserWithBasicRole(User registerInfo) {
        //保存用户信息
        boolean flag = save(registerInfo);
        if (flag){
            //获取用户ID
            int userId = getUserByAccount(registerInfo.getAccount()).getUserId();
            //设置基本角色
            int basicRoleId = Constants.ROLE_ID_BASIC;
            //向用户角色表插入数据，建立用户与基本角色的关联
            int insertLine = userRoleMapper.insert(new UserRole(userId,basicRoleId));
            return insertLine>0;

        }
        return false;
    }
    //根据账号信息获取用户信息
    public User getUserByAccount(String account){
        QueryWrapper<User>wrapper = new QueryWrapper<>();
        //动态构建查询条件，查询满足 account = #{account}的用户
        wrapper.eq("account",account);
        return getOne(wrapper);
    }
    //根据登录信息获取用户信息
    public User getUserByLoginInfo(User loginInfo){
        return getOne(
                new QueryWrapper<User>()
                .eq("account",loginInfo.getAccount())
                .eq("password",loginInfo.getPassword())
        );
    }

    @Override
    public Page<User> pageByCondition(IPage page, String account) {
        return (Page<User>) page(
                page,
                new QueryWrapper<User>().like(StringUtils.hasLength(account),"account",account)
        );
    }
}




