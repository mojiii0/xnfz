package com.hwadee.xnfz.controller;

import com.hwadee.xnfz.common.Constants;
import com.hwadee.xnfz.entity.Dictionary;
import com.hwadee.xnfz.entity.R;
import com.hwadee.xnfz.service.DictionaryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;

@Api(tags = "字典表管理")
@RestController
@RequestMapping("/dictionary")
public class DictionaryController {

    @Autowired
    DictionaryService dictionaryService;

    @ApiOperation("获取性别字典数据")
    @GetMapping("/gender/list")
    public R getGenderList(){
        List<Dictionary> genderList = dictionaryService.listByType(Constants.TYPE_DICTIONARY_GENDER);

        return R.ok().data(genderList);
    }
    @ApiOperation("获取类别获取所有字典表数据")
    @GetMapping("/list/{type}")
    public R listByType(@PathVariable("type") String type){
        List<Dictionary> list = dictionaryService.listByType(type);
        return R.ok().data(list);
    }

    @ApiOperation("获取类别获取所有字典表数据对应的 Map")
    @GetMapping("/list/map/{type}")
    public R listMapByType(@PathVariable("type") String type){
        List<Dictionary> list = dictionaryService.listByType(type);

        //将字典表数据映射成 map
        HashMap<Integer,String> map = new HashMap<>();
        list.forEach(
                item ->{
                    map.put(item.getCode(),item.getName());
                }
        );

        return R.ok().data(map);
    }
}
