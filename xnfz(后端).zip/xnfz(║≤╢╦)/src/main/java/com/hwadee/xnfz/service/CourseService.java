package com.hwadee.xnfz.service;

import com.hwadee.xnfz.entity.Course;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * @author 16326
 * @description 针对表【course】的数据库操作Service
 * @createDate 2023-08-09 15:59:43
 */
public interface CourseService extends IService<Course> {

    public Course getUserByName(String name);

    void saveUser(Course course);

    public List<Course> getAllCourse();
    void deleteCourseById(Long id);
    Course getCourseById(Long id);
    List<Course> listByCondition(String name, String number);

}
