package com.hwadee.xnfz.controller;

import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hwadee.xnfz.common.Constants;
import com.hwadee.xnfz.common.MD5Util;
import com.hwadee.xnfz.common.TokenUtil;
import com.hwadee.xnfz.entity.Dictionary;
import com.hwadee.xnfz.entity.Menu;
import com.hwadee.xnfz.entity.R;
import com.hwadee.xnfz.entity.User;
import com.hwadee.xnfz.service.DictionaryService;
import com.hwadee.xnfz.service.MenuService;
import com.hwadee.xnfz.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;



@Api(tags = "用户管理")
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;
    @Autowired
    DictionaryService dictionaryService;
    @Autowired
    MenuService menuService;

    @ApiOperation("访问测试接口")
    @GetMapping("/test")
    public R test(){

        return R.fail(R.CODE_NOT_CERTIFIED).message("未认证，请先登录");
    }

    @ApiOperation("根据注册信息中的用户名，验证用户是否存在")
    @GetMapping("/register/validate/{account}")
    public R validateAccountByRegister(@PathVariable("account") String account){
        //验证数据的合法性
        if(!StringUtils.hasLength(account)){
            //参数格式不正确，验证失败
            return R.fail().message("参数格式不正确，验证失败");
        }
        //验证数据的有效性
        User user = userService.getUserByAccount(account);
        if(user != null){
            //用户已存在，反馈给注册界面错误信息
            return R.fail().message("用户已存在，不能重复使用");
        }else {
            //用户不存在，反馈给注册界面正确信息
            return R.ok().message("用户不存在，可以使用");
        }
    }

    @ApiOperation("用户注册")
    @PostMapping("/register")
    public R register(@RequestBody User registerInfo){
        //数据校验
        R r = validateAccountByRegister(registerInfo.getAccount());
        if(r.getStatus()!=R.CODE_OK){
            return r;
        }
        //验证密码
        if(!StringUtils.hasLength(registerInfo.getPassword())){
            return R.fail().message("密码不能为空");
        }else if (registerInfo.getPassword().length()<4 || registerInfo.getPassword().length()>20){
            return R.fail().message("请输入 4 到 20 位之间的密码");
        }
        //密码加密，提高数据的安全性
        registerInfo.setPassword(MD5Util.encryptMd5AndSalt(registerInfo.getPassword()));
        //验证姓名
        if(!StringUtils.hasLength(registerInfo.getUsername())){
            return R.fail().message("姓名不能为空");
        }
        //TODO 根据数据库动态查询
        Dictionary dictionary = dictionaryService.getOneByTypeAndCode(Constants.TYPE_DICTIONARY_GENDER,
                registerInfo.getGender());
        if(dictionary == null){
            return R.fail().message("性别数据不合理");
        }
        //验证电话号码
        if(!StringUtils.hasLength(registerInfo.getPhone())){
            return R.fail().message("电话号码不能为空");
        }else if (!Pattern.matches("^1[3|4|5|6|7|8|9][0-9]{9}$",registerInfo.getPhone())){
            return R.fail().message("电话号码格式不正确");
        }

        //验证邮箱
        if (!StringUtils.hasLength(registerInfo.getEmail())){
            return R.fail().message("邮箱不能为空");
        }else if (!Pattern.matches("\\w+@(\\w+\\.){1,3}[a-zA-Z]{2,3}",registerInfo.getEmail())){
            return R.fail().message("邮箱格式不正确");
        }

        boolean flag = userService.saveUserWithBasicRole(registerInfo);
        if (flag){
            return R.ok().message("恭喜你，注册成功");
        }else {
            return R.fail().message("注册失败!");
        }


    }

    @ApiOperation("根据登录信息中的用户名，验证用户是否存在")
    @GetMapping("/login/validate/{account}")
    public R validateAccountByLogin(@PathVariable("account") String account){
        if (!StringUtils.hasLength(account)){
            return R.fail().message("参数格式不正确，验证失败");
        }

        //验证数据的有效性
        User user = userService.getUserByAccount(account);
        if(user != null){
            //用户名对应的用户数据是存在的，反馈给登录页面正确信息
            return R.ok().message("用户名验证通过");
        }else {
            //用户名对应的用户数据不存在，反馈给登录界面错误信息
            return R.fail().message("用户名不存在，验证不通过");
        }
    }

    @ApiOperation("用户登录")
    @PostMapping("/login")
    public R login(@RequestBody User loginInfo, HttpSession session){
        //TODO 一般不会出现，以防万一
        if (loginInfo == null){
            return R.fail().message("用户不存在，验证不通过");
        }
        if(!StringUtils.hasLength(loginInfo.getPassword())){
            return R.fail().message("密码不能为空");
        }else if (loginInfo.getPassword().length()<4 || loginInfo.getPassword().length()>20){
            return R.fail().message("请输入 4 到 20 位之间的密码");
        }
        //对密码进行加密验证，匹配注册时的加密策略
        loginInfo.setPassword(MD5Util.encryptMd5AndSalt(loginInfo.getPassword()));

        User user = userService.getUserByLoginInfo(loginInfo);
        if (user != null){

            session.setAttribute("userId",user.getUserId());
            //登录成功
            //生成Token
            String token = TokenUtil.sign(user.getUserId());
            //根据用户角色，动态加载菜单权限
            List<Menu> menus = menuService.listByUserId(user.getUserId());

            HashMap<String,Object> resultMap = new HashMap<>();
            resultMap.put("user",user);
            resultMap.put("token", token);
            resultMap.put("menus",menus);
            return R.ok().message("登录成功").data(resultMap);
        }else {
            return R.fail().message("用户名或密码错误");
        }
    }

    @ApiOperation("用户注销")
    @GetMapping("/logout")
    public R logout(HttpSession session){
        session.removeAttribute("userId");

        return R.ok().message("注销成功");
    }

    @ApiOperation("获取所有用户数据")
    @GetMapping("/list")
    public R list(){
        List<User> users = userService.list();
        return R.ok().data(users);
    }

    @ApiOperation("获取用户分页数据")
//    @GetMapping(value = {"/page/{current}"})
    public R page(@PathVariable("current") int current,
                  @RequestParam(defaultValue = "10",required = false) int size){
        Page<User> page = userService.page(Page.of(current,size));
        return R.ok().data(page);
    }

    @ApiOperation("根据条件获取用户分页数据")
    @GetMapping(value = {"/page/{current}"})
    public R pageByCondition(@PathVariable("current") int current,
                             @RequestParam(defaultValue = "10",required = false) int size,
                             @RequestParam(required = false) String account ){
        Page<User> page = userService.pageByCondition(Page.of(current,size),account);
        return R.ok().data(page);
    }

    @ApiOperation("新增一条用户数据")
    @PostMapping("/item")
    public R save(@RequestBody User user){
        if(!StringUtils.hasLength(user.getPassword())){
            return R.fail().message("密码不能为空");
        }else if (user.getPassword().length()<4 || user.getPassword().length()>20){
            return R.fail().message("请输入 4 到 20 位之间的密码");
        }
        //密码加密，提高数据的安全性
        user.setPassword(MD5Util.encryptMd5AndSalt(user.getPassword()));

        //验证姓名
        if(!StringUtils.hasLength(user.getUsername())){
            return R.fail().message("姓名不能为空");
        }

        //验证电话号码
        if(!StringUtils.hasLength(user.getPhone())){
            return R.fail().message("电话号码不能为空");
        }else if (!Pattern.matches("^1[3|4|5|6|7|8|9][0-9]{9}$",user.getPhone())){
            return R.fail().message("电话号码格式不正确");
        }

        //验证邮箱
        if (!StringUtils.hasLength(user.getEmail())){
            return R.fail().message("邮箱不能为空");
        }else if (!Pattern.matches("\\w+@(\\w+\\.){1,3}[a-zA-Z]{2,3}",user.getEmail())){
            return R.fail().message("邮箱格式不正确");
        }
        if (user.getType() != null && user.getType() == 5) {
            return R.fail().message("不能新增教学秘书");
        }else{
            user.setPassword(MD5Util.encryptMd5AndSalt(user.getPassword()));
            boolean flag = userService.save(user);
            if (flag) {
                return R.ok().message("新增用户成功");
            } else {
                return R.fail().message("新增用户失败");
            }
        }

    }
    @ApiOperation("删除一条用户数据")
    @DeleteMapping("/item/{id}")
    public R remove(@PathVariable int id){
        User user = userService.getById(id);
        if (user.getType() == null || user.getType() != 5) {
            // 执行删除用户数据操作
            boolean flag = userService.removeById(id);
            if (flag) {
                return R.ok().message("删除用户成功");
            } else {
                return R.fail().message("删除用户失败");
            }
        } else {
            return R.fail().message("不能删除教学秘书");
        }
    }


    @ApiOperation("修改一条用户数据")
    @PutMapping("/item")
    public R update(@RequestBody User user) {
        User originalUser = userService.getById(user.getUserId()); // 查询原始数据
        if (!StringUtils.hasLength(user.getPassword())) {
            // 如果密码字段为空，保持原始密码不变
            user.setPassword(originalUser.getPassword());
        } else {
            // 密码字段不为空，进行加密处理
            user.setPassword(MD5Util.encryptMd5AndSalt(user.getPassword()));
        }
        //验证姓名
        if(!StringUtils.hasLength(user.getUsername())){
            return R.fail().message("姓名不能为空");
        }

        //验证电话号码
        if(!StringUtils.hasLength(user.getPhone())){
            return R.fail().message("电话号码不能为空");
        }else if (!Pattern.matches("^1[3|4|5|6|7|8|9][0-9]{9}$",user.getPhone())){
            return R.fail().message("电话号码格式不正确");
        }

        //验证邮箱
        if (!StringUtils.hasLength(user.getEmail())){
            return R.fail().message("邮箱不能为空");
        }else if (!Pattern.matches("\\w+@(\\w+\\.){1,3}[a-zA-Z]{2,3}",user.getEmail())){
            return R.fail().message("邮箱格式不正确");
        }
        if (user.getType() == null || user.getType() != 5) {
            // 执行删除用户数据操作
            boolean flag = userService.updateById(user);
            if (flag) {
                return R.ok().message("修改用户成功");
            } else {
                return R.fail().message("修改用户失败");
            }
        } else {
            return R.fail().message("不能修改教学秘书信息");
        }

    }

    @ApiOperation("获取一条用户数据")
    @GetMapping ("/item/{id}")
    public R getById(@PathVariable int id) {
        User user = userService.getById(id);
        if (user!=null) {
            return R.ok().data(user);
        } else {
            return R.fail().message("未查询到相关数据");
        }
    }

    @ApiOperation("导入用户")
    @PostMapping("/import")
    public R importExcel(@RequestParam("file") MultipartFile file) throws IOException {
        boolean save = false;
        InputStream inputStream = null;

        try {
            ImportParams param = new ImportParams();
            param.setTitleRows(1);  // 标题占几行
            param.setHeadRows(1);   // 文件头占几行
            inputStream = file.getInputStream();
            List<User> users = ExcelImportUtil.importExcel(inputStream, User.class, param);

            // 遍历导入的用户数据
            for (User user : users) {
                // 检查账户是否存在
                User isExistingUser = userService.getUserByAccount(user.getAccount());
                if (isExistingUser != null) {
                    return R.fail().message("账户已存在，导入失败");
                } else {
                    if (user.getType() != null && user.getType() == 5) {
                        return R.fail().message("不能导入教学秘书");
                    } else {
                        // 密码加密并导入
                        user.setPassword(MD5Util.encryptMd5AndSalt(user.getPassword()));
                    }
                }
            }

            save = userService.saveOrUpdateBatch(users);
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (save) {
            return R.ok().message("上传成功");
        } else {
            return R.fail().message("上传失败");
        }
    }

    @ApiOperation("批量用户")
    @DeleteMapping("/del/batch")
    public R deleteBatch(@RequestParam("id") String ids) {
        String[] split = ids.split(",");
        List<Integer> list = new ArrayList<>();

        for (String s : split) {
            list.add(Integer.parseInt(s));
        }

        List<User> users = userService.listByIds(list);
        for (User user : users) {
            if (user.getType() != null && user.getType() == 5) {
                return R.fail().message("不能删除教学秘书");
            }
        }

        boolean del = userService.removeByIds(list);
        if (del) {
            return R.ok().message("删除数据成功");
        }
        return R.fail().message("删除数据失败");
    }


}
