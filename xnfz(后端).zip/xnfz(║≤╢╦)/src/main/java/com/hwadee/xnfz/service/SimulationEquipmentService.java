package com.hwadee.xnfz.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.hwadee.xnfz.entity.SimulationEquipment;

import java.util.List;

public interface SimulationEquipmentService extends IService<SimulationEquipment> {

    Page<SimulationEquipment> pageByCondition(IPage page, String name, String number);

    List<SimulationEquipment> listByCondition(String name,String number);
}
