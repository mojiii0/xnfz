package com.hwadee.xnfz.mapper;

import com.hwadee.xnfz.entity.Dictionary;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Administrator
* @description 针对表【dictionary】的数据库操作Mapper
* @createDate 2023-07-29 16:51:27
* @Entity com.hwadee.xnfz.entity.Dictionary
*/
public interface DictionaryMapper extends BaseMapper<Dictionary> {

}




