package com.hwadee.xnfz.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hwadee.xnfz.entity.Experiment;
import com.hwadee.xnfz.service.ExperimentService;
import com.hwadee.xnfz.mapper.ExperimentMapper;
import org.springframework.stereotype.Service;

/**
* @author Administrator
* @description 针对表【experiment】的数据库操作Service实现
* @createDate 2023-08-17 15:37:05
*/
@Service
public class ExperimentServiceImpl extends ServiceImpl<ExperimentMapper, Experiment>
    implements ExperimentService{

}




