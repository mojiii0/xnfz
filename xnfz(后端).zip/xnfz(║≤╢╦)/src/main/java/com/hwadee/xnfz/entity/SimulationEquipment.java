package com.hwadee.xnfz.entity;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

@TableName(value ="simulation_equipment")
@Data
@ToString
public class SimulationEquipment implements Serializable {
    @TableId(type = IdType.AUTO)
    private Integer simulationEquipmentId;
    @Excel(name = "设备编号")
    private String number;
    @Excel(name = "设备名称")
    private String name;
    @Excel(name = "设备类型",replace = {"个人计算机 _0","一体机_1","大屏_2"})
    private Integer type;
    @Excel(name = "软件系统")
    private String softwareSystem;
    @Excel(name = "版本号")
    private String version;
    @Excel(name = "设备供应商")
    private String supplier;
    @Excel(name = "用途")
    private String purpose;
    @Excel(name = "设备状态",replace = {"正常 _0","报修_1","损坏_2"})
    private Integer status;
    @Excel(name = "设备缩略图")
    private String thumbnail;
    @Excel(name = "创建时间",databaseFormat = "yyyy-MM-dd HH:mm:ss",exportFormat = "yyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime = new Date();
    @Excel(name = "更新时间",databaseFormat = "yyyy-MM-dd HH:mm:ss",exportFormat = "yyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;
    @TableLogic
    private Integer deleted;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        SimulationEquipment other = (SimulationEquipment) that;
        return (this.getSimulationEquipmentId() == null ? other.getSimulationEquipmentId() == null : this.getSimulationEquipmentId().equals(other.getSimulationEquipmentId()))
            && (this.getNumber() == null ? other.getNumber() == null : this.getNumber().equals(other.getNumber()))
            && (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getType() == null ? other.getType() == null : this.getType().equals(other.getType()))
            && (this.getSoftwareSystem() == null ? other.getSoftwareSystem() == null : this.getSoftwareSystem().equals(other.getSoftwareSystem()))
            && (this.getVersion() == null ? other.getVersion() == null : this.getVersion().equals(other.getVersion()))
            && (this.getSupplier() == null ? other.getSupplier() == null : this.getSupplier().equals(other.getSupplier()))
            && (this.getPurpose() == null ? other.getPurpose() == null : this.getPurpose().equals(other.getPurpose()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getThumbnail() == null ? other.getThumbnail() == null : this.getThumbnail().equals(other.getThumbnail()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getDeleted() == null ? other.getDeleted() == null : this.getDeleted().equals(other.getDeleted()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getSimulationEquipmentId() == null) ? 0 : getSimulationEquipmentId().hashCode());
        result = prime * result + ((getNumber() == null) ? 0 : getNumber().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getType() == null) ? 0 : getType().hashCode());
        result = prime * result + ((getSoftwareSystem() == null) ? 0 : getSoftwareSystem().hashCode());
        result = prime * result + ((getVersion() == null) ? 0 : getVersion().hashCode());
        result = prime * result + ((getSupplier() == null) ? 0 : getSupplier().hashCode());
        result = prime * result + ((getPurpose() == null) ? 0 : getPurpose().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getThumbnail() == null) ? 0 : getThumbnail().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getDeleted() == null) ? 0 : getDeleted().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", simulationEquipmentId=").append(simulationEquipmentId);
        sb.append(", number=").append(number);
        sb.append(", name=").append(name);
        sb.append(", type=").append(type);
        sb.append(", softwareSystem=").append(softwareSystem);
        sb.append(", version=").append(version);
        sb.append(", supplier=").append(supplier);
        sb.append(", purpose=").append(purpose);
        sb.append(", status=").append(status);
        sb.append(", thumbnail=").append(thumbnail);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", deleted=").append(deleted);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}