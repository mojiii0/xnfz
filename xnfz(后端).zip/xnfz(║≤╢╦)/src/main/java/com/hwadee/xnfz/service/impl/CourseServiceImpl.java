package com.hwadee.xnfz.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hwadee.xnfz.entity.Course;
import com.hwadee.xnfz.service.CourseService;
import com.hwadee.xnfz.mapper.CourseMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * @author 16326
 * @description 针对表【course】的数据库操作Service实现
 * @createDate 2023-08-09 15:59:43
 */
@Service
public class CourseServiceImpl extends ServiceImpl<CourseMapper, Course>
        implements CourseService{

    @Override
    public Course getUserByName(String name){
        QueryWrapper<Course> wrapper = new QueryWrapper<Course>().eq("name",name);

        return getOne(wrapper);
    }

    @Override
    public void saveUser(Course course) {
        save(course);

    }
    @Override
    public List<Course> getAllCourse(){
        return list();
    }
    @Override
    public void deleteCourseById(Long id) {
        // 调用DAO层的方法来删除用户
        removeById(id);
    }
    @Override
    public Course getCourseById(Long id) {
        return getById(id);
    }

    @Override
    public List<Course> listByCondition(String name, String number){
        return  list(
                new QueryWrapper<Course>()
                        .like(StringUtils.hasLength(name),"name",name)
                        .like(StringUtils.hasLength(number),"number", number)
        );
    }


}




