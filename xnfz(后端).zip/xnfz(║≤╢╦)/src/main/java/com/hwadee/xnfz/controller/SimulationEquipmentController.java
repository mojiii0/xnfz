package com.hwadee.xnfz.controller;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.net.HttpHeaders;
import com.hwadee.xnfz.entity.R;
import com.hwadee.xnfz.entity.SimulationEquipment;
import com.hwadee.xnfz.service.DictionaryService;
import com.hwadee.xnfz.service.SimulationEquipmentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Api(tags = "仿真设备管理")
@RestController
@RequestMapping("/equipment")
public class SimulationEquipmentController {

    @Autowired
    SimulationEquipmentService simulationEquipmentService;
    @Autowired
    DictionaryService dictionaryService;


    @ApiOperation("获取所有仿真设备数据")
    @GetMapping("/list")
    public R list(){
        List<SimulationEquipment> equipments = simulationEquipmentService.list();
        return R.ok().data(equipments);
    }

    @ApiOperation("获取仿真设备分页数据")
//    @GetMapping(value = {"/page/{current}"})
    public R page(@PathVariable("current") int current,
                  @RequestParam(defaultValue = "10") int size){
        Page<SimulationEquipment> page = simulationEquipmentService.page(Page.of(current,size));
        return R.ok().data(page);
    }

    @ApiOperation("根据不同条件分页仿真设备数据")
    @GetMapping("/page/{current}")
    public R pageByCondition(@PathVariable("current") int current,
                      @RequestParam(required = false) int pageSize,
                      @RequestParam(required = false) String name,
                      @RequestParam(required = false) String number) {

        QueryWrapper<SimulationEquipment> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByDesc("simulation_equipment_id");
        if (!"".equals(name)) {
            queryWrapper.like("name", name);
        }
        if (!"".equals(number)) {
            queryWrapper.like("number", number);
        }
        Page<SimulationEquipment> page = simulationEquipmentService.page(new Page<>(current, pageSize), queryWrapper);
        return R.ok().data(page);
    }

    @ApiOperation("导出仿真设备")
    @GetMapping("/export")
    public void export(HttpServletResponse  response,
                       @RequestParam(required = false) String name,
                       @RequestParam(required = false) String number) throws IOException {
        //生成 Excel 的对象
        List<SimulationEquipment> equipments = simulationEquipmentService.listByCondition(name,number);
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams("仿真设备信息详情表",  "sheet 名称"), SimulationEquipment.class, equipments);
        //response 写出Excel
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION,"attachment;filename="+ URLEncoder.encode("simulation_equipment.xlsx","utf-8"));
        response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
        workbook.write(response.getOutputStream());
    }

    @ApiOperation("导入excel")
    @PostMapping("/import")
    public R importExcel(@RequestParam("file") MultipartFile file) throws IOException {
        boolean save = false;
        InputStream inputStream = null;
        //System.out.println(file.isEmpty());
        try {
            ImportParams param = new ImportParams();
            param.setTitleRows(1);  //标题占几行
            param.setHeadRows(1);   //文件头占几行
            inputStream = file.getInputStream();
            List<SimulationEquipment> equipments = ExcelImportUtil.importExcel(inputStream, SimulationEquipment.class, param);
            //System.out.println(equipments);
            save = simulationEquipmentService.saveOrUpdateBatch(equipments);//添加进入数据库，若有重复的不添加
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (save){
            return R.ok().message("上传成功");
        }else{
            return R.fail().message("上传失败");
        }
    }

    //TODO 增删改查
    @ApiOperation("新增或修改仿真设备")
    @PostMapping("/item")
    public R save(@RequestBody SimulationEquipment simulationEquipment){
        if (!StringUtils.hasLength(simulationEquipment.getName())){
            return R.fail().message("设备名称不能为空");
        }
        if (!StringUtils.hasLength(simulationEquipment.getNumber())){
            return R.fail().message("设备编号不能为空");
        }
        simulationEquipment.setCreateTime(new Date());
        simulationEquipment.setUpdateTime(new Date());
        boolean save = simulationEquipmentService.saveOrUpdate(simulationEquipment);
        if (save){
            return R.ok().message("新增数据成功");
        }
        return R.fail().message("新增数据失败");
    }

    @ApiOperation("删除仿真设备")
    @DeleteMapping("/del/{id}")
    public R delete(@PathVariable Integer id) {
        boolean del = simulationEquipmentService.removeById(id);
        if (del){
            return R.ok().message("删除数据成功");
        }
        return R.fail().message("删除数据失败");
    }

    @ApiOperation("批量删除仿真设备")
    @DeleteMapping("/del/batch")
    public R deleteBatch(@RequestParam("id") String ids) {
        String[] split = ids.split(",");
        List<Integer> list = new ArrayList<>();
        for (String s : split) {
            list.add(Integer.parseInt(s));
        }
        System.out.println(list);
        boolean del = simulationEquipmentService.removeByIds(list);
        if (del){
            return R.ok().message("删除数据成功");
        }
        return R.fail().message("删除数据失败");
    }

}
