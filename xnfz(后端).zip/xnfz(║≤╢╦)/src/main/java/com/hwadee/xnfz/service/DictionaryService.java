package com.hwadee.xnfz.service;

import com.hwadee.xnfz.entity.Dictionary;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
* @author Administrator
* @description 针对表【dictionary】的数据库操作Service
* @createDate 2023-07-29 16:51:27
*/
public interface DictionaryService extends IService<Dictionary> {

    Dictionary getOneByTypeAndCode(String type,int code);

    List<Dictionary> listByType(String type);
}
