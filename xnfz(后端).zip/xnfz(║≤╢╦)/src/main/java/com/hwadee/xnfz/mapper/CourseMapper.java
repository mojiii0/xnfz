package com.hwadee.xnfz.mapper;

import com.hwadee.xnfz.entity.Course;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 16326
* @description 针对表【course】的数据库操作Mapper
* @createDate 2023-08-14 16:57:02
* @Entity com.hwadee.xnfz.entity.Course
*/
public interface CourseMapper extends BaseMapper<Course> {

}




