package com.hwadee.xnfz.common;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Util {

    public static final String DEFAULT_SALT = "xnfz";

    public static String encryptMd5AndSalt(String password) {
        try {
            //将 password 和 盐值拼接
            String dataSalt = password + "{" + DEFAULT_SALT + "}";

            //获取 MD5 算法对象
            MessageDigest digest = MessageDigest.getInstance("MD5");

            //加入信息摘要
            digest.update(dataSalt.getBytes(StandardCharsets.UTF_8));

            //获取数据的信息摘要
            byte[] bytes = digest.digest();

            //将字节数组转化为16进制的加密结果
            return fromBytesToHex(bytes);
        } catch (NoSuchAlgorithmException e) {
            System.out.println(password + " -> " + e.getMessage());
            return null;
        }
    }


    /**
     * 将给定的字节数组，转化为16进制数据
     */
    private static String fromBytesToHex(byte[] resultBytes) {
        StringBuilder builder = new StringBuilder();
        for (byte resultByte : resultBytes) {
            if (Integer.toHexString(0xFF & resultByte).length() == 1) {
                builder.append("0").append(Integer.toHexString(0xFF & resultByte));
            } else {
                builder.append(Integer.toHexString(0xFF & resultByte));
            }
        }
        return builder.toString();
    }

}
