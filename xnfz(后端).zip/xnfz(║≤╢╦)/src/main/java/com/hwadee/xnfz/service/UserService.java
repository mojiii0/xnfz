package com.hwadee.xnfz.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hwadee.xnfz.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author Administrator
* @description 针对表【user】的数据库操作Service
* @createDate 2023-07-29 08:15:37
*/
public interface UserService extends IService<User> {

boolean saveUserWithBasicRole(User registerInfo);

    public User getUserByAccount(String account);

    public User getUserByLoginInfo(User loginInfo);

    Page<User> pageByCondition(IPage page, String account);

}
