package com.hwadee.xnfz;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.hwadee.xnfz.mapper")
public class Xnfz02Application {

    public static void main(String[] args) {
        SpringApplication.run(Xnfz02Application.class, args);
    }

}
