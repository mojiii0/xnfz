package com.hwadee.xnfz.controller;

import com.hwadee.xnfz.common.Constants;
import com.hwadee.xnfz.entity.Dictionary;
import com.hwadee.xnfz.entity.R;
import com.hwadee.xnfz.service.DictionaryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(tags = "字典表管理")
@RestController
@RequestMapping("/dictionary")
public class DictionaryController {

    @Autowired
    DictionaryService dictionaryService;

    @ApiOperation("获取性别字典列表")
    @GetMapping("/gender/list")
    public R getGenderList(){
        List<Dictionary> genderList = dictionaryService.listByType(Constants.TYPE_DICTIONARY_GENDER);
        return R.ok().data(genderList);
    }
}
