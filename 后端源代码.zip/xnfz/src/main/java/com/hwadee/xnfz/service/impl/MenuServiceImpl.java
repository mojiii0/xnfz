package com.hwadee.xnfz.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hwadee.xnfz.entity.Menu;
import com.hwadee.xnfz.service.MenuService;
import com.hwadee.xnfz.mapper.MenuMapper;
import org.springframework.stereotype.Service;

import java.util.List;

/**
* @author Administrator
* @description 针对表【menu】的数据库操作Service实现
* @createDate 2023-08-03 13:01:14
*/
@Service
public class MenuServiceImpl extends ServiceImpl<MenuMapper, Menu>
    implements MenuService{


    @Override
    public List<Menu> listByUserId(int userId) {
        return baseMapper.listByUserId(userId);
    }
}




