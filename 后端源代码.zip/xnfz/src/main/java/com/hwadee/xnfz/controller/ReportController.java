package com.hwadee.xnfz.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hwadee.xnfz.entity.Experiment;
import com.hwadee.xnfz.entity.R;
import com.hwadee.xnfz.entity.Report;
import com.hwadee.xnfz.entity.User;
import com.hwadee.xnfz.service.ExperimentService;
import com.hwadee.xnfz.service.ReportService;
import com.hwadee.xnfz.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import jdk.nashorn.internal.objects.NativeString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.apache.commons.io.FilenameUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Base64;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.stream.Stream;

@Api(tags = "实验报告管理")
@RestController
@RequestMapping("/report")
public class ReportController {
//    @Value("${report.upload.directory}")
//    private String reportUploadDirectory;
    private static final String BASE_UPLOAD_DIR = "E:/a实训3/华迪/大项目/xnfz/uploads";  // 修改为实际的基础上传目录
    @Autowired
    ReportService reportService;
    @Autowired
    UserService userService;
    @Autowired
    ExperimentService experimentService;

    @ApiOperation("获取学生的个人实验报告")
    @GetMapping(value = {"/page/{current}"})
    public R pageByStudentId(@PathVariable("current") int current,
                             @RequestParam(defaultValue = "10", required = false) int size,
                             @RequestParam(required = false) int studentId
    ) {

        Page<Report> page = reportService.pageByStudentId(Page.of(current, size), studentId);
        return R.ok().data(page);
    }

    @ApiOperation("获取实验报告")
    @GetMapping(value = {"/pageall/{current}"})
    public R page(@PathVariable("current") int current,
                             @RequestParam(defaultValue = "10", required = false) int size
    ) {

        Page<Report> page = reportService.page(Page.of(current, size));
        return R.ok().data(page);
    }

    @ApiOperation("学生查询实验报告")
    @GetMapping(value = {"/search/{current}"})
    public R pageByName(@PathVariable("current") int current,
                             @RequestParam(defaultValue = "10", required = false) int size,
                             @RequestParam(required = false) int studentId,
                             @RequestParam(required = false) String name) {

        Page<Report> page = reportService.pageByStuIdAndName(Page.of(current, size), studentId, name);
        return R.ok().data(page);
    }
    @ApiOperation("查询实验报告")
    @GetMapping(value = {"/searchByName/{current}"})
    public R searchByName(@PathVariable("current") int current,
                        @RequestParam(defaultValue = "10", required = false) int size,
                        @RequestParam(required = false) String name) {

        Page<Report> page = reportService.pageByName(Page.of(current, size),  name);
        return R.ok().data(page);
    }
    @ApiOperation("通过Id获取实验报告")
    @GetMapping(value = {"/getByreportId/{reportId}"})
    public R getByreportId(@PathVariable("reportId") int reportId) {

        Report report = reportService.getByreportId(reportId);
        return R.ok().data(report);
    }

    @ApiOperation("新增实验报告")
    @PostMapping(value = "/add/{studentId}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public R addReport(@PathVariable("studentId") int studentId, @RequestParam("file") MultipartFile file, Report report) throws IOException {
        if (file.getSize() > 25 * 1024 * 1024) {
            return R.fail().message("File size should not exceed 25MB!");
        }

        // 根据实验报告ID创建文件夹
        String experimentName = experimentService.getById(report.getExperimentId()).getName();
        String experimentFolderPath = Paths.get(BASE_UPLOAD_DIR, String.valueOf(report.getExperimentId()), experimentName).toString();
        File experimentFolder = new File(experimentFolderPath);
        if (!experimentFolder.exists()) {
            experimentFolder.mkdirs();
        }

        // 生成实验报告文件夹路径
        String reportName = report.getName();
        String originalFileName = file.getOriginalFilename();
        String uniquePrefix = System.currentTimeMillis() + "_" + (int) (Math.random() * 900 + 100) + "_";
        String uniqueFileName = uniquePrefix + StringUtils.cleanPath(originalFileName);
        String fileName = StringUtils.cleanPath(uniqueFileName); // 在此处使用 uniqueFileName
        String reportFolderPath = Paths.get(experimentFolderPath, reportName).toString();
        File reportFolder = new File(reportFolderPath);
        if (!reportFolder.exists()) {
            reportFolder.mkdirs();
        }
        Path filePath = Paths.get(reportFolderPath, fileName);

        System.out.println("Experiment Folder Path: " + experimentFolderPath);
        System.out.println("Report Folder Path: " + reportFolderPath);
        System.out.println("File Path: " + filePath);

        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        report.setFileName(fileName);
        report.setPath(reportFolderPath);
        String number = "No" + System.currentTimeMillis() + (int) (Math.random() * 900 + 100);
        report.setNumber(number);
        report.setStudentId(studentId);
        report.setStatus(1);
        report.setStudentName(userService.getById(studentId).getUsername());

        // 更新实验报告记录
        boolean flag = reportService.saveOrUpdate(report);
        if (flag) {
            return R.ok().message("新增实验报告成功");
        } else {
            return R.fail().message("新增实验报告失败");
        }
    }


    @ApiOperation("删除实验报告")
    @DeleteMapping("/delete/{reportId}")
    public R deleteReport(@PathVariable("reportId") int reportId) {
        // 根据 reportId 查询实验报告信息
        Report report = reportService.getById(reportId);
        if (report == null) {
            return R.fail().message("实验报告不存在");
        }
        String reportFolderPath = report.getPath();
        Path pathToDelete = Paths.get(reportFolderPath);

        try {
            if (Files.exists(pathToDelete)) {
                if (Files.isDirectory(pathToDelete)) {
                    // 删除文件夹下的特定文件，如要删除的文件名为 "fileToDelete.docx"
                    Path fileToDelete = pathToDelete.resolve(report.getFileName());
                    if (Files.exists(fileToDelete)) {
                        Files.delete(fileToDelete);
                    }

                    // 列出文件夹中的所有文件
                    try (Stream<Path> walk = Files.walk(pathToDelete)) {
                        long count = walk.filter(Files::isRegularFile).count();
                        if (count == 0) {
                            // 文件夹为空，可以删除
                            Files.walk(pathToDelete)
                                    .sorted(Comparator.reverseOrder())
                                    .map(Path::toFile)
                                    .forEach(File::delete);
                        }
                    }
                } else {
                    // 删除单个文件
                    Files.delete(pathToDelete);
                }
            }
        } catch (IOException e) {
            return R.fail().message("删除实验报告文件失败");
        }
        // 删除数据库中的实验报告记录
        boolean success = reportService.removeById(reportId);
        if (success) {
            return R.ok().message("删除实验报告成功");
        } else {
            return R.fail().message("删除实验报告失败");
        }
    }

    @ApiOperation("修改实验报告")
    @PostMapping (value ="/update", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public R updateReport(@RequestParam("file") MultipartFile file,  Report updatedReport) throws IOException {
        if (file.getSize() > 25 * 1024 * 1024) {
            return R.fail().message("File size should not exceed 25MB!");
        }

        // 根据实验报告ID获取原始报告信息
        Report originalReport = reportService.getById(updatedReport.getReportId());
        if (originalReport == null) {
            return R.fail().message("Report not found");
        }

        String reportFolderPath = originalReport.getPath();
        Path pathToDelete = Paths.get(reportFolderPath);

        try {
            if (Files.exists(pathToDelete)) {
                if (Files.isDirectory(pathToDelete)) {
                    // 获取要删除的文件的路径
                    Path fileToDelete = pathToDelete.resolve(originalReport.getFileName());

                    // 如果文件存在，则删除
                    if (Files.exists(fileToDelete)) {
                        Files.delete(fileToDelete);
                    }

                    // 列出文件夹中的所有文件
                    try (Stream<Path> walk = Files.walk(pathToDelete)) {
                        long count = walk.filter(Files::isRegularFile).count();
                        if (count == 0) {
                            // 文件夹为空，可以删除
                            Files.delete(pathToDelete);
                        }
                    }
                } else {
                    // 删除单个文件
                    Files.delete(pathToDelete);
                }
            }
        } catch (IOException e) {
            return R.fail().message("删除实验报告文件失败");
        }

        String experimentName = experimentService.getById(updatedReport.getExperimentId()).getName();
        String experimentFolderPath = Paths.get(BASE_UPLOAD_DIR, String.valueOf(updatedReport.getExperimentId()), experimentName).toString();
        File experimentFolder = new File(experimentFolderPath);
        if (!experimentFolder.exists()) {
            experimentFolder.mkdirs();
        }

        String reportName = updatedReport.getName();
        String originalFileName = file.getOriginalFilename();
        String uniquePrefix = System.currentTimeMillis() + "_" + (int) (Math.random() * 900 + 100) + "_";
        String uniqueFileName = uniquePrefix + StringUtils.cleanPath(originalFileName);
        String fileName = StringUtils.cleanPath(uniqueFileName); // 在此处使用 uniqueFileName
        String updateReportFolderPath = Paths.get(experimentFolderPath, reportName).toString();
        File updatereportFolder = new File(updateReportFolderPath);
        if (!updatereportFolder.exists()) {
            updatereportFolder.mkdirs();
        }
        Path filePath = Paths.get(updateReportFolderPath, fileName);
        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        // 更新实验报告信息
//        Integer grade = updatedReport.getGrade();
//        Integer teacherId = updatedReport.getTeacherId();
//
//        // 如果 grade 或 teacherId 为 0，则将其转换为 null
//        if (grade != null && grade.equals(0)) {
//            grade = null;
//        }
//
//        if (teacherId != null && teacherId.equals(0)) {
//            teacherId = null;
//        }
        updatedReport.setFileName(fileName);
        updatedReport.setPath(updateReportFolderPath);

        // 其他实验报告信息更新操作，例如更新分数、状态等

        boolean flag = reportService.updateReport(updatedReport);
        if (flag) {
            return R.ok().message("修改实验报告成功");
        } else {
            return R.fail().message("修改实验报告失败");
        }
    }
    @PutMapping("/examine")
    public R examineReportByTeacher(@RequestBody Report report) {
        report.setTeacherName(userService.getById(report.getTeacherId()).getUsername());

        boolean flag = reportService.examineReportByTeacher(report);
        if (flag) {
            return R.ok().message("审核完成");
        } else {
            return R.fail().message("审核失败");
        }
    }
//    @GetMapping("/download")
//    public ResponseEntity<Resource> downloadFile(@RequestParam String filename, @RequestParam String path) throws IOException {
//        Path filePath = Paths.get(path, filename);
//        Resource resource = new FileSystemResource(filePath.toFile());
//
//        return ResponseEntity.ok()
//                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
//                .body(resource);
//    }




    @GetMapping("/download")
    public ResponseEntity<Resource> downloadFile(@RequestParam String filename, @RequestParam String path) throws IOException {
        // Construct the file path based on the given path and filename
        String filePath = Paths.get(path, filename).toString();

        // Load the file as a Resource
        Resource fileResource = new FileSystemResource(filePath);

        // Encode the filename in ISO-8859-1 and then URL encode it
        String encodedFilename = URLEncoder.encode(filename, String.valueOf(StandardCharsets.ISO_8859_1));

        // Set the Content-Disposition header
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + encodedFilename + "\"");

        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(fileResource.contentLength())
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(fileResource);
    }





}
