package com.hwadee.xnfz.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hwadee.xnfz.common.Constants;
import com.hwadee.xnfz.entity.User;
import com.hwadee.xnfz.entity.UserRole;
import com.hwadee.xnfz.mapper.UserRoleMapper;
import com.hwadee.xnfz.service.UserService;
import com.hwadee.xnfz.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
* @author Administrator
* @description 针对表【user】的数据库操作Service实现
* @createDate 2023-07-28 15:27:58
*/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
    implements UserService {

    @Autowired
    UserRoleMapper userRoleMapper;

    @Transactional
    @Override
    public boolean saveUserWithBasicRole(User registerInfo) {
        boolean flag = save(registerInfo);
        if (flag) {
            int userId = getUserByAccount(registerInfo.getAccount()).getUserId();
            int basicRoleId = Constants.ROLE_ID_BASIC;

            int insertLine = userRoleMapper.insert(new UserRole(userId,basicRoleId));
            return  insertLine >0;
        }
        return false;
    }

    @Override
    public User getUserByAccount(String account) {
        QueryWrapper<User> wrapper = new QueryWrapper<User>().eq("account",account);
        return getOne(wrapper);
    }

    @Override
    public User getUserBylogininfo(User logininfo) {
        QueryWrapper<User> wrapper = new QueryWrapper<User>().eq("account",logininfo.getAccount())
                                        .eq("password",logininfo.getPassword());
        return getOne(wrapper);
    }

    @Override
    public List<User> getUser() {
        QueryWrapper<User> wrapper = new QueryWrapper<User>();
        return list(wrapper);
    }


}




