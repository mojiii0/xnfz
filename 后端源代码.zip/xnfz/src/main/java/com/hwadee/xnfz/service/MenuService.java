package com.hwadee.xnfz.service;

import com.hwadee.xnfz.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
* @author Administrator
* @description 针对表【menu】的数据库操作Service
* @createDate 2023-08-03 13:01:14
*/
public interface MenuService extends IService<Menu> {
    public List<Menu> listByUserId(int userId);
}
