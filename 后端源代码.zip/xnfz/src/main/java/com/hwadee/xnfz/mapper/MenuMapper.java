package com.hwadee.xnfz.mapper;

import com.hwadee.xnfz.entity.Menu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
* @author Administrator
* @description 针对表【menu】的数据库操作Mapper
* @createDate 2023-08-03 13:01:14
* @Entity com.hwadee.xnfz.entity.Menu
*/
public interface MenuMapper extends BaseMapper<Menu> {
    List<Menu> listByUserId(@Param("userId") int userId);
}




