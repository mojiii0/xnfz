package com.hwadee.xnfz.service;

import com.hwadee.xnfz.entity.Experiment;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author Administrator
* @description 针对表【experiment】的数据库操作Service
* @createDate 2023-08-10 16:52:21
*/
public interface ExperimentService extends IService<Experiment> {

}
