package com.hwadee.xnfz.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hwadee.xnfz.entity.Report;
import com.hwadee.xnfz.service.ReportService;
import com.hwadee.xnfz.mapper.ReportMapper;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
* @author Administrator
* @description 针对表【report】的数据库操作Service实现
* @createDate 2023-08-10 17:08:55
*/
@Service
public class ReportServiceImpl extends ServiceImpl<ReportMapper, Report>
    implements ReportService{

    @Autowired
    ReportMapper reportMapper;


    @Override
    public Page<Report> pageByStudentId(IPage page,int studentId) {

        return (Page<Report>) page(
                page,
                new QueryWrapper<Report>()
                .eq("student_id",studentId)
        );
    }

    @Override
    public boolean updateReport(Report report) {

        return update(
                 new UpdateWrapper<Report>()
                         .set("experiment_id",report.getExperimentId())
                         .set("name",report.getName())
                         .set("file_name",report.getFileName())
                         .set("path",report.getPath())
                         .eq("report_id",report.getReportId())
        );
    }

    @Override
    public boolean examineReportByTeacher(Report report) {
        return update(
                new UpdateWrapper<Report>()
                        .set("teacher_id",report.getTeacherId())
                        .set("teacher_name",report.getTeacherName())
                        .set("grade",report.getGrade())
                        .set("scoring_opinions",report.getScoringOpinions())
                        .set("status",2)
                        .eq("report_id",report.getReportId())
        );
    }

    @Override
    public Page<Report> pageByStuIdAndName(IPage page, int studentId, String name) {
        return (Page<Report>) page(
                page,
                new QueryWrapper<Report>()
                        .eq("student_id", studentId)
                        .like(StringUtils.hasLength(name), "name", name)
        );
    }


    @Override
    public Report getByreportId(int reportId) {

        return getOne(new QueryWrapper<Report>()
                        .eq("report_id",reportId));
    }

    @Override
    public Page<Report> pageByName(IPage page, String name) {
        return (Page<Report>) page(
                page,
                new QueryWrapper<Report>()
                        .like(StringUtils.hasLength(name), "name", name)
        );
    }
}




