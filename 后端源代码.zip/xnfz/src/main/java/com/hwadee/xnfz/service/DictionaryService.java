package com.hwadee.xnfz.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.hwadee.xnfz.entity.Dictionary;
import org.springframework.stereotype.Service;

import java.util.List;


public interface DictionaryService extends IService<Dictionary> {
    public Dictionary getOneByTypeAndCode(String type, int code);

    List<Dictionary> listByType(String type);
}
