package com.hwadee.xnfz.mapper;

import com.hwadee.xnfz.entity.Experiment;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Administrator
* @description 针对表【experiment】的数据库操作Mapper
* @createDate 2023-08-10 16:52:21
* @Entity com.hwadee.xnfz.entity.Experiment
*/
public interface ExperimentMapper extends BaseMapper<Experiment> {

}




