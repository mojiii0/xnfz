package com.hwadee.xnfz.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * 
 * @TableName report
 */
@TableName(value ="report")
@Data
public class Report implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer reportId;

    /**
     * 
     */
    private Integer experimentId;

    /**
     * 
     */
    private Integer studentId;

    /**
     * 
     */
    private Integer teacherId;

    /**
     * 
     */
    private String number;

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private String studentName;

    /**
     * 
     */
    private String teacherName;

    /**
     * 
     */
    private Integer grade;

    /**
     * 
     */
    private String scoringOpinions;

    /**
     * 
     */
    private Integer status;

    /**
     * 
     */
    private String fileName;

    /**
     * 
     */
    private String path;

    /**
     * 
     */
    @JsonFormat(timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime = new Date();

    /**
     * 
     */

    @JsonFormat(timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime = new Date();


}