package com.hwadee.xnfz.mapper;

import com.hwadee.xnfz.entity.UserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Administrator
* @description 针对表【user_role】的数据库操作Mapper
* @createDate 2023-08-07 16:47:33
* @Entity com.hwadee.xnfz.entity.UserRole
*/
public interface UserRoleMapper extends BaseMapper<UserRole> {
    int deleteByPrimaryKey(Long id);

    int insert(UserRole record);

    int insertSelective(UserRole record);

    UserRole selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(UserRole record);

    int updateByPrimaryKey(UserRole record);
}




