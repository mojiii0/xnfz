package com.hwadee.xnfz.entity;



import java.io.Serializable;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
* 
* @TableName dictionary
*/
@TableName(value ="dictionary")
@Data
public class Dictionary implements Serializable {

    /**
    * 
    */
    @TableId
    @ApiModelProperty("")
    private Integer dictionaryId;
    /**
    * 
    */
    @ApiModelProperty("")
    private String name;
    /**
    * 
    */
    @ApiModelProperty("")
    private Integer code;
    /**
    * 
    */
    @ApiModelProperty("")
    private Integer isranked;
    /**
    * 
    */

    @ApiModelProperty("")
    private String type;
    /**
    * 
    */
    @ApiModelProperty("")
    private String remark;
    /**
    * 
    */
    @ApiModelProperty("")
    private Date createTime;
    /**
    * 
    */
    @ApiModelProperty("")
    private Date updateTime;

    /**
    * 
    */
    public void setDictionaryId(Integer dictionaryId){
    this.dictionaryId = dictionaryId;
    }

    /**
    * 
    */
    public void setName(String name){
    this.name = name;
    }

    /**
    * 
    */
    public void setCode(Integer code){
    this.code = code;
    }

    /**
    * 
    */
    public void setIsranked(Integer isranked){
    this.isranked = isranked;
    }

    /**
    * 
    */
    public void setType(String type){
    this.type = type;
    }

    /**
    * 
    */
    public void setRemark(String remark){
    this.remark = remark;
    }

    /**
    * 
    */
    public void setCreateTime(Date createTime){
    this.createTime = createTime;
    }

    /**
    * 
    */
    public void setUpdateTime(Date updateTime){
    this.updateTime = updateTime;
    }


    /**
    * 
    */
    public Integer getDictionaryId(){
    return this.dictionaryId;
    }

    /**
    * 
    */
    public String getName(){
    return this.name;
    }

    /**
    * 
    */
    public Integer getCode(){
    return this.code;
    }

    /**
    * 
    */
    public Integer getIsranked(){
    return this.isranked;
    }

    /**
    * 
    */
    public String getType(){
    return this.type;
    }

    /**
    * 
    */
    public String getRemark(){
    return this.remark;
    }

    /**
    * 
    */
    public Date getCreateTime(){
    return this.createTime;
    }

    /**
    * 
    */
    public Date getUpdateTime(){
    return this.updateTime;
    }

}
