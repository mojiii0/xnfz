package com.hwadee.xnfz.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hwadee.xnfz.entity.Report;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author Administrator
* @description 针对表【report】的数据库操作Service
* @createDate 2023-08-10 17:08:55
*/
public interface ReportService extends IService<Report> {

    public Page<Report> pageByStudentId(IPage page, int studentId);
    public boolean updateReport(Report report);
    public boolean examineReportByTeacher(Report report);
    public Page<Report> pageByStuIdAndName(IPage page,int studentId,String name);
    public Report getByreportId(int reportId);
    public Page<Report> pageByName(IPage page,String name);
}
