package com.hwadee.xnfz.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hwadee.xnfz.entity.Dictionary;

public interface DictionaryMapper extends BaseMapper<Dictionary> {
}
