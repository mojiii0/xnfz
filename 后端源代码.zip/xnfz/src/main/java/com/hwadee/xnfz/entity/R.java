package com.hwadee.xnfz.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@ApiModel
public class R {
    public static final int CODE_OK=200;
    public static final int CODE_FAIL=0;
    public static final int CODE_NOT_CERTIFIED=401;
    public static final int CODE_EXPIRED=402;

    @ApiModelProperty("响应状态码")
    private int status;
    @ApiModelProperty("响应描述")
    private String message;
    @ApiModelProperty("响应数据")
    private Object data;

    public static R ok(){
        R r = new R();
        r.status = CODE_OK;
        return r;
    }
    public static R fail(){
        R r = new R();
        r.status = CODE_FAIL;
        return r;
    }
    public static R fail(int error_status){
        R r = new R();
        r.status = error_status;
        return r;
    }
    public R message(String message){
        this.message = message;
        return this;
    }
    public R data(Object data){
        this.data = data;
        return this;
    }

    public boolean isOK() {
        return this.status == CODE_OK;
    }
}
