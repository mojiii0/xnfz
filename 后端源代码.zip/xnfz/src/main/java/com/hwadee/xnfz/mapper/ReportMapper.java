package com.hwadee.xnfz.mapper;

import com.hwadee.xnfz.entity.Report;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Administrator
* @description 针对表【report】的数据库操作Mapper
* @createDate 2023-08-10 17:08:55
* @Entity com.hwadee.xnfz.entity.Report
*/
public interface ReportMapper extends BaseMapper<Report> {

}




