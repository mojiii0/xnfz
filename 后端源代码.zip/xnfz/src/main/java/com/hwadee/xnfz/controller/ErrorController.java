package com.hwadee.xnfz.controller;

import com.hwadee.xnfz.entity.R;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/error")
public class ErrorController {

    @RequestMapping("/not_certified")
    public R notCertified(){
        //未认证响应
        return R.fail(R.CODE_NOT_CERTIFIED).message("用户未认证，请先登录！");

    }
    @RequestMapping("/expired")
    public R expired(){
        //认证已过期响应
        return R.fail(R.CODE_EXPIRED).message("认证已过期，请重新登录！");

    }
}
