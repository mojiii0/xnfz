package com.hwadee.xnfz;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.hwadee.xnfz.mapper")
public class XnfzApplication {

    public static void main(String[] args) {
        SpringApplication.run(XnfzApplication.class, args);
    }

}
