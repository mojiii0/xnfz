package com.hwadee.xnfz.interceptor;


import com.hwadee.xnfz.common.TokenUtil;
import com.hwadee.xnfz.entity.R;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerInterceptor;
import sun.plugin.dom.core.Element;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Component
public class TokenInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,Object handler) throws Exception{
        System.out.println("拦截到请求：" + request.getRequestURI());
//        return true;
//        所有OPTIONS请求都通过
        if(request.getMethod().equalsIgnoreCase("OPTIONS")){
            response.setStatus(HttpServletResponse.SC_OK);
            return true;

        }
        //获取Token
        String token = request.getHeader("token");
        //验证Token
        HttpSession session = request.getSession();
        if(token == null){
            //未认证
            //通过内部转发到 未认证接口
            request.getRequestDispatcher("/error/not_certified").forward(request,response);
            return false;
        } else if(!TokenUtil.verify(token)){
            //认证已过期
            //通过内部转发到 认证已过期接口
            request.getRequestDispatcher("/error/expired").forward(request,response);
            return false;
        }


        Object userId = session.getAttribute("userId");
        if(userId == null){
            request.getRequestDispatcher("/error/expired").forward(request,response);
            return false;
        }
        Integer claim = TokenUtil.getClaim(token);
        response.setHeader("token",TokenUtil.sign(claim));
        response.setHeader("Access-Control-Expose-Headers","token");
        return true;
    }
}




//@RestController
//@RequestMapping("/error")
//public class Tokenlnterceptor  {
//    @GetMapping("/not_certified")
//    public R notCertified() {
//        return R.fail().message("认证不通过，请先登录！");
//    }
//    @GetMapping("/expired")
//    public R expired(){
//        return R.fail().message("认证已过期，请先登录！");
//    }
//}