package com.hwadee.xnfz.common;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.util.Date;

/**
 * @author king
 * @date 2023/7/31 10:00
 * @desc Token 生成与验证
 */
public class TokenUtil {
    //秘钥
    public static final String DEFAULT_SALT = "xnfz";
    private static final String DEFAULT_CLAIM = "userId";
    private static final String DEFAULT_ISSUER = "auth0";

    private static final long EXPIRE_TIME = 10 * 60 * 1000;

    /**
     * 根据 用户名 生成加密 Token
     *
     * @param userId
     * @return
     */
    public static String sign(int userId) {
        Date date = new Date(System.currentTimeMillis() + EXPIRE_TIME);

        String token = JWT.create()
                //认证参数
                .withClaim(DEFAULT_CLAIM, userId)
                //Issuer 参数
                .withIssuer(DEFAULT_ISSUER)
                //过期时间
                .withExpiresAt(date)
                //以指定加密算法生成 Token
                .sign(Algorithm.HMAC256(DEFAULT_SALT));

        return token;
    }

    /**
     * 根据 Token 判定认证数据是否有效
     *
     * @param token
     * @return
     */
    public static boolean verify(String token) {
        JWTVerifier verifier = JWT.require(Algorithm.HMAC256(DEFAULT_SALT)).withIssuer(DEFAULT_ISSUER).build();
        DecodedJWT decodedJWT = verifier.verify(token);

        Date expiresAt = decodedJWT.getExpiresAt();
        Integer userId = decodedJWT.getClaim(DEFAULT_CLAIM).asInt();

        return userId > 0 && expiresAt.getTime() > System.currentTimeMillis();
    }

    /**
     * 根据 Token 获取参数 userId
     *
     * @param token
     * @return
     */
    public static int getClaim(String token) {
        JWTVerifier verifier = JWT.require(Algorithm.HMAC256(DEFAULT_SALT))
                .withIssuer(DEFAULT_ISSUER).build();
        DecodedJWT decodedJWT = verifier.verify(token);

        return decodedJWT.getClaim(DEFAULT_CLAIM).asInt();
    }


}
