package com.hwadee.xnfz.controller;

import com.hwadee.xnfz.common.Constants;
import com.hwadee.xnfz.common.MD5Util;
import com.hwadee.xnfz.common.TokenUtil;
import com.hwadee.xnfz.entity.Dictionary;
import com.hwadee.xnfz.entity.Menu;
import com.hwadee.xnfz.entity.R;
import com.hwadee.xnfz.entity.User;
import com.hwadee.xnfz.service.DictionaryService;
import com.hwadee.xnfz.service.MenuService;
import com.hwadee.xnfz.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

@Api(tags = "用户管理")
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;
    @Autowired
    DictionaryService dictionaryService;
    @Autowired
    MenuService menuService;
    @ApiOperation("访问测试接口")
    @GetMapping("/test")
    public String test(){
        return "这是一条测试数据!";
    }


    @ApiOperation("根据注册信息中的用户名，验证用户是否存在")
    @GetMapping("/register/validate/{account}")
    public R valiateAccountByRegister(@PathVariable("account") String account){
        if(!StringUtils.hasLength(account)){
            return R.fail().message("格式不正确，验证失败");
        }
        User user = userService.getUserByAccount(account);
        if(user != null){
            return R.fail().message("用户名已存在，不可重复使用");
        }else{
//
            return R.ok().message("用户名可注册");
        }
    }
    @ApiOperation("提交注册信息注册")
    @PostMapping("/register")
    public R register(@RequestBody User registerInfo){
        R r = valiateAccountByRegister(registerInfo.getAccount());
        if(!r.isOK()){
            return r;
        }
        if(!StringUtils.hasLength(registerInfo.getPassword())){
            return R.fail().message("密码不能为空");
        }else if (registerInfo.getPassword().length()<4||registerInfo.getPassword().length()>20){
            return R.fail().message("请输入4-20位之间的密码");
        }
        registerInfo.setPassword(MD5Util.encryptMd5AndSalt(registerInfo.getPassword()));
        if(!StringUtils.hasLength(registerInfo.getUsername())){
            return R.fail().message("姓名不能为空");
        }
//        if (registerInfo.getGender()<0){
//            return R.fail().message("性别数据不合理");
//        }
        Dictionary dictionary = dictionaryService.getOneByTypeAndCode(Constants.TYPE_DICTIONARY_GENDER, registerInfo.getGender());
        if(dictionary == null){
            return R.fail().message("性别数据不合理");
        }

        if(!StringUtils.hasLength(registerInfo.getPhone())){
            return R.fail().message("电话号码不能为空");
        }else if (!Pattern.matches("^1[3|4|5|6|7|8|9][0-9]{9}$",registerInfo.getPhone())){
            return R.fail().message("电话号码格式不正确");
        }
        if (!StringUtils.hasLength(registerInfo.getEmail())){
            return R.fail().message("邮箱不能为空");
        }else if (!Pattern.matches("\\w+@(\\w+\\.){1,3}[a-zA-Z]{2,3}",registerInfo.getEmail())){
            return R.fail().message("邮箱格式不正确");
        }

        boolean flag = userService.saveUserWithBasicRole(registerInfo);
        System.out.println(flag);
        if (flag) {
            return R.ok().message("注册成功");
        }else
            return R.fail().message("注册失败");
    }
    @ApiOperation("用户登录")
    @PostMapping("/login")
    public R login(@RequestBody User loginInfo) {
        if(loginInfo == null){
            return R.fail().message("参数不合理，请检查后重试");
        }
        if(!StringUtils.hasLength(loginInfo.getPassword())){
            return R.fail().message("密码不能为空");
        }else if (loginInfo.getPassword().length()<4||loginInfo.getPassword().length()>20){
            return R.fail().message("请输入4-20位之间的密码");
        }
        loginInfo.setPassword(MD5Util.encryptMd5AndSalt(loginInfo.getPassword()));
        User loginUser = userService.getUserBylogininfo(loginInfo);
        if (loginUser != null) {
            //登录成功
//            return R.ok().data(loginUser);
            List<Menu> menus = menuService.listByUserId(loginUser.getUserId());
            HashMap<String,Object> result = new HashMap<>();
            result.put("user",loginUser);
            result.put("token", TokenUtil.sign(loginUser.getUserId()));
            result.put("menus",menus);
            return R.ok().message("登录成功").data(result);
        }

        return R.fail().message("用户名或密码不正确");
    }

    @ApiOperation("根据登录信息中的用户名，验证用户是否存在")
    @GetMapping("/login/validate/{account}")
    public R valiateAccountByLogin(@PathVariable("account") String account){
        if(!StringUtils.hasLength(account)){
            return R.fail().message("格式不正确，验证失败");
        }
        User user = userService.getUserByAccount(account);
        if(user == null){
            return R.fail().message("用户名不存在");
        }else{
//
            return R.ok().message("用户名通过");
        }

    }
    @ApiOperation("用户注销")
    @GetMapping("/logout")
    public R logout(HttpSession session){
        session.removeAttribute("userId");

        return R.ok().message("注销成功");
    }



    @ApiOperation("获取用户")
    @GetMapping("/getUser")
    public R getUser(){
        List<User> userList = userService.getUser();
        if(userList == null){
            return R.fail().message("用户名不存在");
        }else{
//
            return R.ok().data(userList);
        }
    }

}
