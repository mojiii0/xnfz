package com.hwadee.xnfz.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hwadee.xnfz.entity.Dictionary;
import com.hwadee.xnfz.mapper.DictionaryMapper;
import com.hwadee.xnfz.service.DictionaryService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DictionaryServiceImpl extends ServiceImpl<DictionaryMapper, Dictionary> implements DictionaryService {
    @Override
    public Dictionary getOneByTypeAndCode(String type, int code){
        return getOne(new QueryWrapper<Dictionary>()
                .eq("type",type)
                .eq("code",code));
    }

    @Override
    public List<Dictionary> listByType(String type) {
        return list(
                new QueryWrapper<Dictionary>()
                .eq("type",type));
    }
}
