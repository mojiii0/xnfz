package com.hwadee.xnfz.service;

import com.hwadee.xnfz.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
* @author Administrator
* @description 针对表【user】的数据库操作Service
* @createDate 2023-07-28 15:27:58
*/
public interface UserService extends IService<User> {
    public boolean saveUserWithBasicRole(User registerInfo);
    public User getUserByAccount(String account);
    public User getUserBylogininfo(User logininfo);
    public List<User> getUser();
}
