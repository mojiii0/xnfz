let user = {
	id:'id',
	username:'username',
	token:'token',
}
let menu = {
	list: 'menu_list'
}
let report = {
	
}
export {
	user,
	menu,
	report
}
