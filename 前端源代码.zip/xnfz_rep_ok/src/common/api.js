//定义访问的接口，并将接口输出

let userUrl = {
	login: "/user/login",
	logout: "/user/logout",
	register:"/user/register",
	valiateAccountByLogin:"/user/login/validate/{account}",
	valiateAccountByRegister:"/user/register/validate/{account}",
	getUser:"user/getUser",
}
let dictionaryUrl ={
	genderList:"/dictionary/gender/list",
}
let reportUrl ={
	pageByStudentId:"/report/page/",
	addReport: "/report/add/",
	deleteReport: "/report/delete/",
	pageByName:"/report/search/",
	updateReport:"/report/update",
	getByreportId:"/report/getByreportId/",
	page:"/report/pageall/",
	examine:"/report/examine/",
	searchByName: "/report/searchByName/",
	download:"/report/download",
	
}

export {
	userUrl,
	dictionaryUrl,
	reportUrl
}