import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/login/login.vue'

Vue.use(VueRouter)

const routes = [{
		path: '/',
		name: 'login',
		component: Login
	},
	// {
	// 	path: '/home',
	// 	name: 'home',
	// 	component: () => import('../views/home/index.vue')
	// },
	{
		path: '/register',
		name: 'register',
		component: () => import('../views/register/register.vue')
	},
	{
		path: '/background',
		name: 'background',
		component: () => import('../views/background/background.vue'),
		children: [
			{
				path: '/course',
				name: 'course',
				component: () => import('../views/background/course/course.vue')
			},
			{
				path: '/laboratory',
				name: 'laboratory',
				component: () => import('../views/background/laboratory/laboratory.vue')
			},
			{
				path: '/report',
				name: 'report',
				component: () => import('../views/background/report/report.vue')
			},
			{
				path: '/correct',
				name: 'correct',
				component: () => import('../views/background/correct/correct.vue')
			},
			{
				path: '/home',
				name: 'home',
				component: () => import('../views/background/home/home.vue')
			},
		]
	},


]

const router = new VueRouter({
	mode: 'history',
	base: process.env.BASE_URL,
	routes
})

export default router