"use strict";

import Vue from 'vue';
import axios from "axios";
import router from "vue-router";

// Full config:  https://github.com/axios/axios#request-config
// axios.defaults.baseURL = process.env.baseURL || process.env.apiUrl || '';
// axios.defaults.headers.common['Authorization'] = AUTH_TOKEN;
// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';

let config = {
	// baseURL: process.env.baseURL || process.env.apiUrl || ""
	baseURL: "http://localhost:8090/",
	timeout: 60 * 1000, // Timeout
	withCredentials: true, // Check cross-site Access-Control
};

const _axios = axios.create(config);

_axios.interceptors.request.use(
	function(config) {
		// Do something before request is sent
		return config;
	},
	function(error) {
		// Do something with request error
		return Promise.reject(error);
	}
);

// Add a response interceptor
_axios.interceptors.response.use(
	function(response) {
		// Do something with response data
		//在此处处理网络是否正常的判定
		console.log(response)
		if (response.status == 200) {
			//当网络正常，但是业务请求异常的时候：401 402错误切换到登录页，以外的错误码返回错误数据
			if(response.data.status ==401 ||response.data.status ==402){
				alert(response.data.message)
				router.push("/")
				return	Promise.reject(new Error(response.data.message));
			}
			return response.data;
			
		} else {
			return {
				status: 0,
				message: '网络请求异常'
			}
		}
	},
	function(error) {
		// Do something with response error
		return Promise.reject(error);
	}
);

Plugin.install = function(Vue) {
	Vue.axios = _axios;
	window.axios = _axios;
	Object.defineProperties(Vue.prototype, {
		axios: {
			get() {
				return _axios;
			}
		},
		$axios: {
			get() {
				return _axios;
			}
		},
	});
};

Vue.use(Plugin)

export default Plugin;