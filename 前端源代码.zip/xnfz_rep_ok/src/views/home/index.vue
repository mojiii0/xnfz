<template>
	<el-row class="home">
		<!-- 背景图片 -->
		<div class="div_background">
			<img :src="loginBgImage" width="100%" height="100%" alt="背景图片" />
		</div>

		<el-col :span="8" :offset="8">
			<div class="grid-content bg-purple-light">
				<el-form :model="homeForm" status-icon :rules="rules" ref="ruleForm" label-width="65px"
					class="form_home">
					<el-table :data="userInfoList" style="width: 100%">
					<el-table-column prop="user_id" label="用户ID"></el-table-column>
					<el-table-column prop="account" label="用户名"></el-table-column>
					<el-table-column prop="password" label="课程ID"></el-table-column>
					<el-table-column prop="username" label="课程名称"></el-table-column>
					<el-table-column prop="gender" label="课程ID"></el-table-column>
					<el-table-column prop="phone" label="课程名称"></el-table-column>
					<el-table-column prop="email" label="课程名称"></el-table-column>
					
					<!-- 添加其他需要展示的列 -->
					</el-table>

				</el-form>
			</div>
		</el-col>
	</el-row>
</template>

<script>
	import {
		userUrl
	} from '../../common/api.js'

	export default {
		name: 'LoginView',
		components: {},
		data() {
			return {
				loginBgImage: require('../../assets/loginbg.png'),
				userInfoList: [], // 存储查询到的用户信息列表
				rules: {}, 
				homeForm: {},
			}
		},
		methods: {
			async getUserInfo() {
				try {
					const response = await this.$axios.get(userUrl.getUser); // 假设后端接口是 '/api/getUserInfo'
					
					this.userInfoList = response.data; // 假设后端返回的用户信息是一个数组
					console.log('获取用户信息');
				}catch (error) {
					console.error('获取用户信息失败', error);
				}
			},
		},
		created() {
			this.getUserInfo();
		},
	}
</script>

<style>
	.el-row {
		position: inherit !important;
	}

	div.div_background {
		width: 100%; /* 设置容器宽度 */
		height: 100%;
		top: 0;
		left: 0;
		z-index: -1;
		position: fixed !important;
		opacity: 0.75;
		background-size:cover;
		background-repeat: no-repeat;
		background-position: center;
	}

	.grid-content {
		border-radius: 30px;
		min-height: 36px;
		margin-top: 35% !important;
	}

	.bg-purple-light {
		/* background-color: rgba(255,255,255,0.5); */
		
		
	}

	.form_home {
		position: absolute;
		top: 40%; /* 将顶部定位到父容器中心 */
		left: 50%; /* 将左侧定位到父容器中心 */
		transform: translate(-50%, -50%); /* 使用负的自身宽高的一半来调整中心位置 */
		width: 1000px;
		padding-top: 50px;
		padding-bottom: 50px;
		padding-left: 50px;
		padding-right: 65px;
		text-align: center;
		background-color: rgba(255,255,255,0.7);
		border-radius: 25px;

	}
	h3 {
		color: #000000;
		padding-left: 15px !important;
		margin-bottom: 10% !important;
		text-align:center
	}
	.form_login .btn_login {
		margin-right: 12%;
		width: 80%;
		height: 100%;
		margin-top: 5%;
	}
	.el-input__inner {
		background-color: transparent !important;
	}
	.msg {
		display: block;
		width: 60%;
		margin-bottom: 10px;
		font-size: 13px;
	}

</style>