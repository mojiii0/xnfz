<template>
	<div class="course">课程管理界面</div>
</template>

<script>
	export default {
		name: 'BackgroundCourseView'
	}
</script>

<style>
</style>