<template>
	<div class="report">
		
		<el-form :model="searchForm" ref="searchForm" label-width="100px" class="demo-searchForm" :inline="true">
			<el-form-item class="searchItem" label="实验报告名称:"  prop="name">
					<el-input type="text" v-model="searchForm.name" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item>
				<el-button  @click="searchByName()">查询</el-button>
		
			</el-form-item>
		</el-form>

		<el-table :data="page.records" border style="width: 100%">
			<el-table-column prop="reportId" label="实验报告ID" width='100'>
			</el-table-column>
			<el-table-column prop="number" label="实验报告编号">
			</el-table-column>
			<el-table-column prop="name" label="实验报告名称" width='150'>
			</el-table-column>
			<el-table-column prop="experimentId" label="实验类型Id" width='100'>
			</el-table-column>
			<el-table-column prop="studentId" label="撰写人ID" width='100'>
			</el-table-column>
			<el-table-column prop="studentName" label="撰写人姓名" width='100'>
			</el-table-column>
			<el-table-column prop="teacherName" label="批改人姓名" width='100'>
			</el-table-column>
			<el-table-column prop="fileName" label="实验报告文件" width='150'>
			</el-table-column>
			<el-table-column prop="status" label="状态" width='100'>			
				<template slot-scope="scope">
					<el-tag :type="
						scope.row.status == 1 ? '' :
											'success'

					">
						{{
							scope.row.status == 1 ? '未批改' :
													'已批改' 
						}}
					</el-tag>
				</template>
			</el-table-column>
			<el-table-column  prop="grade" label="成绩" width='50'>
			</el-table-column>
			<el-table-column prop="scoringOpinions" label="评改意见">
			</el-table-column>		
			<el-table-column fixed="right" label="操作" width="250">
				<template slot-scope="scope">
					<el-button @click="downloadFile(scope.row.fileName, scope.row.path)" type="text" size="small">下载文件</el-button>
					<el-button v-if="scope.row.status == 1" @click="showExamine(scope.row)" type="primary"
						size="small" round>批改</el-button>				
					
				</template>
				
			</el-table-column>
		</el-table>
		
		<el-pagination background layout="prev, pager,next" :total="page.total" class="pagi"  @current-change="handlePageChange"></el-pagination>
	
		
		<el-dialog :title="examine.dialogFormTitle" :visible.sync="examine.dialogFormVisible" width="600px">
			
			
		<el-form :model="examine.form" ref="examineForm" label-width="120px" >
			<el-form-item label="实验报告Id" :label-width="formLabelWidth" hidden>
				<el-input v-model="examine.form.reportId"></el-input>
			</el-form-item>	
			<el-form-item label="实验报告编号" :label-width="formLabelWidth" required>
				<el-input v-model="examine.form.number" disabled></el-input>
			</el-form-item>
			<el-form-item label="实验报告名称" :label-width="formLabelWidth" required>
				<el-input v-model="examine.form.name" disabled></el-input>
			</el-form-item>
			<el-form-item label="实验Id" :label-width="formLabelWidth" required>
				<el-input v-model="examine.form.experimentId" disabled></el-input>
			</el-form-item>
			<el-form-item label="撰写人" :label-width="formLabelWidth" required>
				<el-input v-model="examine.form.studentName" disabled></el-input>
			</el-form-item>
			<el-form-item label="成绩" :label-width="formLabelWidth" required>
				<el-input  v-model="examine.form.grade" autocomplete="off" style="width: 300px;"></el-input>
			</el-form-item>
			<el-form-item label="评改意见" :label-width="formLabelWidth" required>
				<el-input v-model="examine.form.scoringOpinions" autocomplete="off" style="width: 300px;"></el-input>
			</el-form-item>
		</el-form>
		<div slot="footer" class="dialog-footer">
				<el-button @click="examine.dialogFormVisible = false">取 消</el-button>
				<el-button type="primary" @click="examineReport('examineForm')">确 定</el-button>
			</div>
		</el-dialog>
	</div>
	


</template>

<script>
	import ElementUI from 'element-ui';
	import 'element-ui/lib/theme-chalk/index.css';
	import {
		// userUrl,
		// dictionaryUrl,
		reportUrl
	} from '../../../common/api.js'
	import {
		user ,
	} from '../../../common/constants.js'
	export default {
		name: 'BackgroundReportView',
		data() {
			return {
				formLabelWidth: '120px',
				page: {
					records: []
				},
				components: {
					...ElementUI},
				current: 1,
				studentId:null,
				name: null,
				reportId: 0,
				
				examine: {
					dialogFormTitle: '批改实验报告',
					dialogFormVisible: false,
					form: {
						reportId: '',
						number: '',
						studentName: '',
						name: '',
						experimentId: '',						
						grade: '',
						scoringOpinions: '',
						teacherId: '',
					}
				},
				searchForm: {
					name: '',
				},
				
			}
		},
		mounted() {		
			this.user_id = localStorage.getItem(user.id);
			this.initPage();
				},
		methods: {
			initPage() {
				this.axios.get(reportUrl.page + this.current)
					.then(
						response => {
							if (response.status) {
								this.page = response.data
							} else {
								alert('未获取到数据')
							}
						}
					)
					.catch(
						error => {
							alert('网络异常')
							console.error(error);
						});
			},
			
			handlePageChange(newPage) {
				console.log("New page:", newPage);
				this.current = newPage; // 更新当前页码
				this.initPage(); // 重新加载数据
			},
			searchByName() {
				this.axios.get(reportUrl.searchByName + this.current,{
					params: {
						name:this.searchForm.name,
					},
				})
					.then(
						response => {
							if (response.status) {
								this.page = response.data
							} else {
								alert('未获取到数据')
							}
						}
					)
					.catch(
						error => {
							alert('网络异常')
							console.error(error);
						});
			},
			resetForm() {
				// 重置表单逻辑
			
					this.examine.form.grade = '';
					this.examine.form.scoringOpinions = '';
			
				// 可以根据需要添加其他表单的重置逻辑
			},
			examineReport(formName) {
				if (!this.examine.form.grade || !this.examine.form.scoringOpinions) {
						this.$message.error('请填写成绩和评改意见');
						return;
					}
				this.$refs[formName].validate((valid) => {
					if (valid) {
						this.axios.put(reportUrl.examine, this.examine.form)
							.then(response => {
								if (response.status) {
									this.$alert(response.message, '提示', {
										confirmButtonText: '确定',
										callback: action => {
											console.log(action);
											this.$message({
												message: response.message,
												type: 'success'
											});
			
											this.examine.dialogFormVisible = false;
											this.resetForm('examine.form');
											this.initPage();
										}
									});
								} else {
									this.$alert(response.message, '提示', {
										confirmButtonText: '确定',
										callback: action => {
											console.log(action);
											this.$message.error(response.message);
										}
									});
								}
							})
							.catch(error => {
								alert('网络异常')
								console.log(error);
							});
					} else {
						console.log('请先完成表单要求的内容');
						return false;
					}
				});
			},
			showExamine(row) {
				this.examine.dialogFormVisible = true;
				this.examine.form.reportId = row.reportId;
				this.examine.form.number = row.number;
				this.examine.form.name = row.name;
				this.examine.form.experimentId = row.experimentId;
				this.examine.form.studentName = row.studentName;
				this.examine.form.teacherId = this.user_id;
			},
			downloadFile(filename, path) {
				
				const url = `http://localhost:8090${reportUrl.download}?filename=${encodeURIComponent(filename)}&path=${encodeURIComponent(path)}`;
				window.open(url, '_blank');
			}
			
		}
	}
</script>

<style>
	.form_select_status {
		width: 100%;
	}
	.dialog-footer {
		margin-right: 35%;
		margin-bottom: 6%;
	}
</style>
