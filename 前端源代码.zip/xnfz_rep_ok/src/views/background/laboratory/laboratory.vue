<template>
	<div class="laboratory">实验室管理界面</div>
</template>

<script>
	export default {
		name: 'BackgroundLaboratoryView'
	}
</script>

<style>
</style>
