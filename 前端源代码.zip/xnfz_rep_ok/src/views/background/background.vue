<template>
	<div class="app-container">
		<el-container style="height: 100%;width: 100%; border: 1px solid #eee;" class="background">
		<!-- 左侧菜单栏 -->
		<el-aside width="200px" class="tac" style="margin-top: 60px;">
			<el-menu router class="el-menu-vertical" default-active="1">
			<el-menu-item v-for="menu in menuList" :key="menu.path" :index="menu.path">
				<i :class="menu.icon"></i>
				<span slot="title">{{menu.menuNameC}}</span>
			</el-menu-item>
			</el-menu>
		</el-aside>

		<el-container>
			<!-- 右侧顶部 Header -->
			<el-header style="text-align: right; font-size: 20px">
			<el-row>
				<el-col :span="20">欢迎来到后台管理系统</el-col>
				<el-col :span="2" ><el-avatar style="margin-top:12px;margin-right: 10px;" size="medium" :src="userImage"></el-avatar></el-col>
				<el-col :span="1" style="text-align: left;margin-top:20px; font-size: 15px;font-weight: 800;"><span>{{user_name}}</span></el-col>
				<el-col :span="1">
				<el-button type="info" class="btn_logout_bg" @click="logout()">注销</el-button>
				</el-col>
			</el-row>
			</el-header>

			<!-- 右侧下方正文部分 -->
			<el-main>
			<router-view></router-view>
				<!-- <span :text="menuList"></span> -->
			</el-main>
		</el-container>
		</el-container>
	</div>
</template>

<script>
	import {
		userUrl
	} from '../../common/api.js'
	import { menu, user } from '../../common/constants.js';
	export default {
		name: 'BackgroundView',
		data() {
		return {
			userImage: require('../../assets/user3bg.png'),
			menuList: [],
			user_name: ''
		};
		},
		mounted() {
			var menulist = localStorage.getItem(menu.list);
			console.log(menulist);
			if (menulist != null) {
			this.menuList = JSON.parse(menulist);
			}
			this.user_name = localStorage.getItem(user.username);
		},
		methods: {
			logout() {
				this.axios.get(userUrl.logout)
					.then(response => {
						if (response.status) {
							this.$message({
								message: '注销成功！',
								type: 'success'
							});
		
							localStorage.clear()
							this.$router.push('/')
						}
					})
					.catch(error => {
						// 处理错误情况
						alert('网络异常')
						console.log(error);
					});
			}
		}
	};
</script>

<style>
	body {
		margin: 0;
	}
	.el-header {
		margin-left: -200px !important;
		color: #409EFF!important;
		width: 110%;
	}
	.el-col.el-col-20 {
		text-align: left !important; 
		font-size: 25px;
		margin-top:15px; 
		font-weight: 600;
		text-align: center;
		font-family: "Arial", "Helvetica", sans-serif;
	}
	
	.app-container {
		
		color: #333;
	}

	.header {
		background-color: #409eff;
		color: #fff;
		text-align: center;
		line-height: 60px;
		font-size: 20px;
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
	}

	.title {
		font-size: 24px;
	}

	.user-name {
		font-size: 14px;
	}

	.tac {
		background-color: #fff;
		color: #333;
		text-align: center;
		line-height: 60px;
		box-shadow: 2px 0 6px rgba(0, 0, 0, 0.1);
	}

	.btn_logout_bg {
		float: right;
		margin-top: 15px;
		background-color: #409eff;
		color: #fff;
		border: none;
		border-radius: 4px;
		padding: 8px 16px;
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
	}

	.el-main {
		background-color: #f5f5f5;
		color: #333;
		text-align: center;
		min-height: 780px;
	}

	.el-container {
		margin-bottom: 40px;
	}

	.el-menu-item i {
		font-size: 18px;
		margin-right: 10px;
	}

	.el-menu-item__title {
		font-size: 16px;
	}
</style>