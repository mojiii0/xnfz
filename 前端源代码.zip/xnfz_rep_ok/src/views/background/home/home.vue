<template>
	<div class="home">后台首页界面</div>
</template>

<script>
	export default {
		name: 'BackgroundHomeView'
	}
</script>

<style>
</style>
