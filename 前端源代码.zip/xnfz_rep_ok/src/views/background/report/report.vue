<template>
	<div class="report">
		
		<el-form :model="searchForm" ref="searchForm" label-width="100px" class="demo-searchForm" :inline="true">
			<el-form-item class="searchItem" label="实验报告名称:"  prop="name">
					<el-input type="text" v-model="searchForm.name" autocomplete="off"></el-input>
			</el-form-item>
			<el-form-item>
				<el-button  @click="searchByName()">查询</el-button>
						<el-button type="primary"
					@click="addType = 1; add.dialogFormVisible = true;  add.form.applyDate = null; add.form.applyDay = 1; add.form.reason = ''">新增</el-button>
		
			</el-form-item>
		</el-form>

		<el-table :data="page.records" border style="width: 100%">
			<el-table-column prop="reportId" label="实验报告ID" width='100'>
			</el-table-column>
			<el-table-column prop="number" label="实验报告编号">
			</el-table-column>
			<el-table-column prop="name" label="实验报告名称" width='150'>
			</el-table-column>
			<el-table-column prop="experimentId" label="实验类型Id" width='100'>
			</el-table-column>
			<el-table-column prop="studentId" label="撰写人ID" width='100'>
			</el-table-column>
			<el-table-column prop="studentName" label="撰写人姓名" width='100'>
			</el-table-column>
			<el-table-column prop="teacherName" label="批改人姓名" width='100'>
			</el-table-column>
			<el-table-column prop="fileName" label="实验报告文件" width='150'>
			</el-table-column>
			<el-table-column prop="status" label="状态" width='100'>			
				<template slot-scope="scope">
					<el-tag :type="
						scope.row.status == 1 ? '' :
											'success'

					">
						{{
							scope.row.status == 1 ? '未批改' :
													'已批改' 
						}}
					</el-tag>
				</template>
			</el-table-column>
			<el-table-column  prop="grade" label="成绩" width='50'>
			</el-table-column>
			<el-table-column prop="scoringOpinions" label="评改意见">
			</el-table-column>		
			<el-table-column fixed="right" label="操作" width="250">
				<template slot-scope="scope">
					<el-button @click="downloadFile(scope.row.fileName, scope.row.path)" type="text" size="small">下载文件</el-button>
					<el-button v-if="scope.row.status == 1 " size="small"
						@click="update.dialogFormVisible = true; fetchAndAddFileToForm(scope.row.reportId);"
						round>编辑</el-button>				
					<el-button v-if="scope.row.status == 1"
						@click="deleteReport(scope.row.reportId)" type="danger" size="small" round>删除</el-button>
					
				</template>
				
			</el-table-column>
		</el-table>
		
		<el-pagination background layout="prev, pager,next" :total="page.total" class="pagi"  @current-change="handlePageChange"></el-pagination>
		
		<el-dialog :title="add.dialogFormTitle" :visible.sync="add.dialogFormVisible" width="600px">
		<el-form :model="add.form" ref="addForm" label-width="120px" >
			<el-form-item label="实验报告名称" :label-width="formLabelWidth" required>
				<el-input type="name" v-model="add.form.name" autocomplete="off" style="width: 300px;"></el-input>
			</el-form-item>
			<el-form-item label="实验ID" :label-width="formLabelWidth" required>
				<el-input v-model="add.form.experimentId" autocomplete="off" style="width: 300px;"></el-input>
			</el-form-item>
			<el-form-item label="实验报告文件" :label-width="formLabelWidth" required>
				<el-upload
				class="upload-demo" 
				ref="upload"
				:action= "uploadAction()"
				:on-success="handleUploadSuccess"
				:auto-upload="false"
				:data="add.form"
				:file-list="add.form.fileList"
				:on-exceed="handleExceed"	
				:before-upload="beforeUpload"
				:limit="1"
				>
				<el-button slot="trigger" type="primary" class="add-input" style="width: 300px;">点击上传</el-button>

				</el-upload>
			</el-form-item>
		</el-form>
		<div slot="footer" class="dialog-footer">
				<el-button @click="add.dialogFormVisible = false">取 消</el-button>
				<el-button type="primary" @click="addReport">确 定</el-button>
			</div>
		</el-dialog>
		
		<el-dialog :title="update.dialogFormTitle" :visible.sync="update.dialogFormVisible" width="600px">
		<el-form :model="update.form" ref="updateForm" label-width="120px" >
			<el-form-item label="实验报告名称" :label-width="formLabelWidth" required>
				<el-input type="name" v-model="update.form.name" autocomplete="off" style="width: 300px;"></el-input>
			</el-form-item>
			<el-form-item label="实验ID" :label-width="formLabelWidth" required>
				<el-input v-model="update.form.experimentId" autocomplete="off" style="width: 300px;"></el-input>
			</el-form-item>
			<el-form-item label="实验报告文件" :label-width="formLabelWidth" required>
				<el-upload
				class="upload-demo" 
				ref="updateUpload"
				:action= "updateUploadAction()"
				:on-success="handleUpadteUploadSuccess"
				:auto-upload="false"
				:file-list="update.form.fileList"
				:data="update.form"
				:on-exceed="handleExceed"	
				:before-upload="beforeUpload"
				:on-change="updateUploadFiles"
				:limit="1"
				>
				<el-button slot="trigger" type="primary" class="add-input" style="width: 300px;">点击上传</el-button>
		
				</el-upload>
			</el-form-item>
		</el-form>
		<div slot="footer" class="dialog-footer">
				<el-button @click="update.dialogFormVisible = false">取 消</el-button>
				<el-button type="primary" @click="updateReport">确 定</el-button>
			</div>
		</el-dialog>
	</div>
	


</template>

<script>
	import ElementUI from 'element-ui';
	import 'element-ui/lib/theme-chalk/index.css';
	import moment from 'moment';
	import {
		// userUrl,
		// dictionaryUrl,
		reportUrl
	} from '../../../common/api.js'
	import {
		user ,
	} from '../../../common/constants.js'
	export default {

		name: 'BackgroundReportView',
		data() {
			return {
				formLabelWidth: '120px',
				page: {
					records: []
				},
				components: {
					...ElementUI},
				current: 1,
				studentId:null,
				name: null,
				reportId: 0,
				add: {
					dialogFormTitle: '新增实验报告',
					dialogFormVisible: false,
					form: {
					name: '',
					experimentId: '',
					fileList: [],
					path: '',
					fileName: '',
					status: '',
					scoringOpinions: '',
					grade: '',
					teacherName: '',
					studentName: '',
					number: '',
					teacherId: '',
					studentId: '',
					reportId: '',
					
					}
				},
				update: {
					dialogFormTitle: '编辑实验报告',
					dialogFormVisible: false,
					form: {
					name: '',
					experimentId: '',
					fileList: [],
					path: '',
					fileName: '',
					}
				},
				
				searchForm: {
					name: '',
				},
				
			}
		},
		mounted() {		
			console.log("Initial fileList:", this.add.form.fileList);
			this.user_id = localStorage.getItem(user.id);
			this.initReportPage();
				},
		methods: {
			initReportPage() {
				this.axios.get(reportUrl.pageByStudentId + this.current,{
					params: {
						studentId:this.user_id,
					},
				})
					.then(
						response => {
							if (response.status) {
								this.page = response.data
							} else {
								alert('未获取到数据')
							}
						}
					)
					.catch(
						error => {
							alert('网络异常')
							console.error(error);
						});
			},
			uploadFiles (item,fileList) {
						this.form.files = fileList
						console.log("打印上传文件详情",fileList)
						
						},
			updateUploadFiles (item,fileList) {
						this.update.form.fileList = fileList
						console.log("打印上传文件详情",fileList)
						
						},
			uploadAction() {
				// 根据需要动态生成上传 URL
				return `http://localhost:8090/${reportUrl.addReport}${this.user_id}`;
				},
			updateUploadAction() {
				return `http://localhost:8090/${reportUrl.updateReport}`;
				
			},
			beforeUpload(file) {
					const isLt25M = (file.size / 1024 / 1024) < 25;
					if (!isLt25M) {
							this.$message.error("上传的文件大小不能超过25MB");
							return false;
						}
						return true;
					
				},
			handleExceed() {
					this.$message.warning(`当前限制选择 1 个文件`);
				},
			handleError(err) {
				this.$message.info(err.data);
			},
			resetForm(formName) {
				// 重置表单逻辑
				if (formName === 'add.form') {
					this.add.form.name = '';
					this.add.form.experimentId = '';
					this.add.form.fileList = [];
				}
				// 可以根据需要添加其他表单的重置逻辑
			},
			handleUploadSuccess(response) {
				if (response.status) {
						this.$message({
						message: '上传成功',
						type: 'success'
						})
						this.resetForm('add.form');
						this.$refs.upload.clearFiles();
						this.add.dialogFormVisible = false;
						this.initReportPage();
					} else {
						this.$message({
						message: '上传失败',
						type: 'error'
						})
					}

				},
			handleUpadteUploadSuccess(response) {
				if (response.status) {
						this.$message({
						message: '上传成功',
						type: 'success'
						})
						// this.resetForm('update.form');
						// this.$refs.updateUpload.clearFiles();
						this.update.dialogFormVisible = false;
						this.initReportPage();
						
					} else {
						this.$message({
						message: '上传失败',
						type: 'error'
						})
					}
				
			},
			addReport() {
				if (!this.add.form.name || !this.add.form.experimentId ) {
						this.$message.error('请填写完整');
						return;
				}
				// if (!this.add.form.fileList || this.add.form.fileList.length === 0) {
				// 		this.$message.error('请上传实验报告文件');
				// 		return;
				// 	}
				this.$refs.upload.submit();
			},
			handlePageChange(newPage) {
				console.log("New page:", newPage);
				this.current = newPage; // 更新当前页码
				this.initReportPage(); // 重新加载数据
			},
			updateReport() {
				if (!this.update.form.name || !this.update.form.experimentId ) {
						this.$message.error('请填写完整');
						return;
				}
				this.$refs.updateUpload.submit();
			// 	this.$refs.updateUpload.axios.put(reportUrl.updateReport, this.update.form,{
			// 		headers: {
			// 		'Content-Type': 'multipart/form-data'
			// 		}});
			},
			deleteReport(id) {
				this.$confirm('此操作将永久删除该申请, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					this.axios.delete(reportUrl.deleteReport + id)
						.then(response => {
							if (response.status) {
								this.$message({
									type: 'success',
									message: '删除成功!'
								});
								this.initReportPage();
							} else {
								this.$message({
									type: 'info',
									message: '删除失败!'
								});
							}
						})
						.catch(error => {
							alert('网络异常')
							console.log(error);
						});
				}).catch(() => {
					this.$message({
						type: 'info',
						message: '已取消删除'
					});
				});
			},
			searchByName() {
				this.axios.get(reportUrl.pageByName + this.current,{
					params: {
						studentId:this.user_id,
						name:this.searchForm.name,
					},
				})
					.then(
						response => {
							if (response.status) {
								this.page = response.data
							} else {
								alert('未获取到数据')
							}
						}
					)
					.catch(
						error => {
							alert('网络异常')
							console.error(error);
						});
			},
			
			fetchAndAddFileToForm(reportId) {
				this.axios.get(reportUrl.getByreportId + reportId)
				.then(response => {
							if (response.status) {								
								this.update.form = response.data
								this.update.form.fileList = [];
								this.update.form.createTime = moment().format('YYYY-MM-DD HH:mm:ss');
								this.update.form.updateTime = moment().format('YYYY-MM-DD HH:mm:ss');
								let gradeValue = parseInt(this.update.form.grade);
								let teacherIdValue = parseInt(this.update.form.teacherId);								
								// 检查是否成功转换为有效的数字，如果不是，设置默认值为0
								if (isNaN(gradeValue)) {
									gradeValue = 0; // 或其他默认值
								}
								if (isNaN(teacherIdValue)) {
									teacherIdValue = 0; // 或其他默认值
								}														// 将处理后的值重新赋值给 form 对象
								this.update.form.grade = gradeValue;
								this.update.form.teacherId = teacherIdValue;	
								const fileName = this.update.form.fileName
								const blob = new Blob([''], { type: 'application/octet-stream' });
								blob.name = fileName; // 设置 Blob 的名称
								const file = new File([blob], fileName, { type: 'application/octet-stream' });
								console.log(this.update.form);	
								this.update.form.fileList.push(file);
								
							} else {
								alert('未获取到数据')
							}
						})
			},
			downloadFile(filename, path) {
				
				const url = `http://localhost:8090${reportUrl.download}?filename=${encodeURIComponent(filename)}&path=${encodeURIComponent(path)}`;
				window.open(url, '_blank');
			}
			
		}
	}
</script>

<style>
	.dialog-footer {
		margin-right: 35%;
		margin-bottom: 6%;
	}
</style>
