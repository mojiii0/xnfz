<template>
	<el-row class="register">
		<!-- 背景图片 -->
		<div class="div_background">
			<img :src="registerBgImage" width="100%" height="100%" alt="背景图片" />
		</div>

		<el-col :span="8" :offset="8">
			<div class="gridContent">
				<el-form :model="registerForm" status-icon :rules="rules" ref="ruleForm" label-width="65px"
					class="form_register">
					<h3>欢迎注册</h3>
					<el-form-item label="账号" prop="account">
						<el-input type="text" v-model="registerForm.account" autocomplete="off"></el-input>
					</el-form-item>
					<el-form-item label="密码" prop="password">
						<el-input type="password" v-model="registerForm.password" autocomplete="off"></el-input>
					</el-form-item>
					<el-form-item label="姓名" prop="username">
						<el-input type="text" v-model="registerForm.username" autocomplete="off"></el-input>
					</el-form-item>
					<el-form-item label="性别" prop="gender">
						<el-select v-model="registerForm.gender" placeholder="请选择性别" class="form_register_gender">
								<el-option v-for="item in genderList" :key="item.code" :label="item.name"
								:value="item.code"></el-option>
						</el-select>						
					</el-form-item>
					<el-form-item label="电话" prop="phone">
						<el-input type="tel" v-model="registerForm.phone" autocomplete="off"></el-input>
					</el-form-item>
					<el-form-item label="邮箱" prop="email">
						<el-input type="email" v-model="registerForm.email" autocomplete="off"></el-input>
					</el-form-item>
					
					<el-button type="primary" @click="submitForm('ruleForm')" class="btn_register">注册</el-button>
					
					
					<el-button @click="backLogin" class="btn_backLogin">>>登录</el-button>
					
				</el-form>
			</div>
		</el-col>
	</el-row>
</template>

<script>
	import {
		userUrl,dictionaryUrl
	} from '../../common/api.js'

	export default {
		name: 'LoginView',
		components: {},
		data() {
			var validAccountByRegister = (rule,value,callback)=>{
			const accountValue = this.registerForm.account;
			const apiUrl = userUrl.valiateAccountByRegister.replace("{account}", accountValue);
			this.axios
				.get(apiUrl)
				.then(response => {
					if (response.status) {
						callback()
					}else {
						callback(new Error(response.message))
					}
				})
				.catch(error => {
					// 处理请求失败的情况
					console.error(error);
					callback(new Error("网络异常无法验证有效性"))
				});
			};
			return {
				registerBgImage: require('../../assets/registerbg.png'),
				registerForm: {
						account: '',
						password: '',
						name: '',
						phone: '15632569987',
						email: '@qq.com'
				},
				rules: {
					account: [{
							required: true,
							message: '账号不能为空',
							trigger: 'blur'
					},
					{
							validator:validAccountByRegister,
							trigger:'blur'
					}],
					password: [{
							required: true,
							message: '密码不能为空',
							trigger: 'blur'
					}],
					username: [{
							required: true,
							message: '姓名不能为空',
							trigger: 'blur'
					}],
					gender: [{
							required: true,
							message: '请选择性别',
							trigger: 'blur'
					}],
					phone: [{
							required: true,
							message: '电话不能为空',
							trigger: 'blur'
						},
						{
							pattern:/^1[3|4|5|6|7|8|9][0-9]{9}$/,
							message:'电话号码格式不正确',
							trigger:'blur'
					}],
					email: [{
							required: true,
							message: '邮箱不能为空',
							trigger: 'blur'
						},
						{
							pattern:/^\w+@(\w+\.){1,3}[a-zA-Z]{2,3}$/,
							message:'邮箱格式不正确',
							trigger:'blur'
					}]
				},
				genderList:[]
			}
		},
		created() {
			this.initGenderList(); // 在这里调用获取 genderList 数据的方法
		},
		methods: {
			initGenderList() {
				this.axios.get(dictionaryUrl.genderList)
					.then(response => {
						console.log(response);
						if (response.status) {
						this.genderList = response.data;
					} else {
						alert('未获取到性别字典数据');
						}
					})
				.catch(function(error){
					alert('网络异常')
					console.log(error)
				});
			},
			submitForm(formName) {
				this.$refs[formName].validate(
					(valid) => {
						if (valid) {
							//验证通过

							console.log('验证通过，可以提交表单了')
							
							this.axios
								.post(userUrl.register, this.registerForm)
								.then(
									response => {
										if (response.status) {
											console.log('注册成功')
											this.$message({
												message: '注册成功',
												type: 'success'
											});
											alert('注册成功')
											//切换到登录
											this.$router.push({
												path: '/'
											})
										} else {
											this.$message.error('注册失败');
											console.log('注册失败')
											alert(response.message)
										}
									}
								)
								.catch(
									error => {
										console.log(error)
									}
								)

						} else {
							//验证不通过
							console.log('规则验证不通过，禁止表单提交')
							return false;
						}
					}
				)
			},
			backLogin() {
				this.$router.push('/'); 
			}
		}
	}
</script>

<style>
	.el-row {
		position: inherit !important;
	}

	div.div_background {
		width: 100%; /* 设置容器宽度 */
		height: 100%;
		top: 0;
		left: 0;
		z-index: -1;
		position: fixed !important;
		opacity: 0.75;
		background-size:cover;
		background-repeat: no-repeat;
		background-position: center;
	}

	.gridContent {
		border-radius: 30px;
		min-height: 36px;
		margin-top: 20% !important;
	}

	.form_register {
		position: absolute;
		top: 40%; /* 将顶部定位到父容器中心 */
		left: 50%; /* 将左侧定位到父容器中心 */
		transform: translate(-50%, -50%); /* 使用负的自身宽高的一半来调整中心位置 */
		width: 380px;
		padding-top: 50px;
		padding-bottom: 50px;
		padding-left: 50px;
		padding-right: 65px;
		text-align: center;
		background-color: rgba(255,255,255,0.7);
		border-radius: 25px;

	}
	h3 {
		color: #000000;
		padding-left: 15px !important;
		margin-bottom: 10% !important;
		text-align:center
	}
	.form_register .btn_register {
		margin-left: 5%;
		width: 30%;
		height: 100%;
		margin-top: 5%;
	}
	.form_register .btn_backLogin {
		margin-left: 10%;
		width: 30%;
		height: 100%;
		margin-top: 5%;
	}
	.el-input__inner {
		background-color: transparent !important;
	}
	.form_register_gender{
		width: 100%;
	}
</style>